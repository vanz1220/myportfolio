<?php

// phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded -- Discussed in Tech Council, a better solution is being worked on.

namespace Yoast\WP\SEO\Exceptions\Addon_Installation;

use Exception;

/**
 * Class Addon_Activation_Error_Exception
 */
class Addon_Activation_Error_Exception extends Exception {}

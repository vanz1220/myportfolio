/*
WP and Divi Icons by Divi Space, an Aspen Grove Studios company
Licensed under the GNU General Public License v3 (see ../license.txt)

This plugin includes code based on parts of the Divi theme and/or the
Divi Builder, Copyright (c) Elegant Themes, licensed GPLv2+, used under GPLv3 (see ../license.txt).
*/

var agsdi_icons_loaded = [], wadi_config = {
	parentIds: '#main-content, #et-main-area, #page-container, #et-boc',
	noBeforeElements: [
		['et_pb_main_blurb_image', 'et_pb_image_wrap'],
		['et_pb_shop'],
		['et_pb_comments_module']
	],
	noAfterElements: [
		['et_pb_main_blurb_image', 'et_pb_image_wrap'],
		['et_pb_shop'],
		['et_pb_comments_module'],
		['et_overlay'],
		['et_font_icon', '*'],
		['et_pb_main_blurb_image', 'et-pb-icon']
	],
	parentsAsClasses: []
};


for (var i = 0; i < wadi_config.noBeforeElements.length; ++i) {
	if (wadi_config.noBeforeElements[i].length == 2 && wadi_config.parentsAsClasses.indexOf(wadi_config.noBeforeElements[i][0]) === -1) {
		wadi_config.parentsAsClasses.push( wadi_config.noBeforeElements[i][0] );
	}
}
for (var i = 0; i < wadi_config.noAfterElements.length; ++i) {
	if (wadi_config.noAfterElements[i].length == 2 && wadi_config.parentsAsClasses.indexOf(wadi_config.noAfterElements[i][0]) === -1) {
		wadi_config.parentsAsClasses.push( wadi_config.noAfterElements[i][0] );
	}
}

window.agsdi_render_icons = function(container, noClasses, reload) {

	var $container = jQuery(container);
	
	$container.find('.et-pb-icon:not([data-icon]),.et-pb-icon:not([data-icon])').each(function() {
		var iconId = jQuery(this).text();
		if (iconId.substr(0,6) == 'agsdi-' || iconId.substr(0,7) == 'agsdix-') {
			jQuery(this).attr('data-icon', iconId).html('').addClass('agsdi-loaded');
		} else {
			jQuery(this).addClass('agsdi-loaded');
		}
	});

	$container.find('[data-icon]').each(function() {
		var $this = jQuery(this), classNames = $this.attr('class'); classNames = classNames ? classNames.split(' ') : [];
		for (var i = 0; i < classNames.length; ++i) {
			var className = classNames[i].trim();
			if (className.substr(0, 7) == 'i-agsdi') {
				$this.removeClass(className);
			}
		}
		
		var iconId = jQuery(this).attr('data-icon');
		
		
		
		if (iconId.substr(0,6) == 'agsdi-' || iconId.substr(0,7) == 'agsdix-') {
			var iconClass = 'i-' + iconId.replace(/ /, '-');
		
			if (!noClasses) {
				$this.addClass(iconClass);
				for (var i = 0; i < wadi_config.parentsAsClasses.length; ++i) {
					if ($this.closest('.' + wadi_config.parentsAsClasses[i]).length) {
						$this.addClass('agsdi-parent-' + wadi_config.parentsAsClasses[i]);
					}
				}
			}
			
			if (window.wadi_icons && window.wadi_icons[iconId]) {
				
				
				var iconSelector = noClasses
								? '[data-icon="' + iconId + '"]'
								: '.' + iconClass,
					parentSelector = '',
					$currentParent = $this.parent().closest(wadi_config.parentIds);
				
				while ($currentParent.length) {
					parentSelector = '#' + $currentParent.attr('id') + ' ' + parentSelector;
					$currentParent = $currentParent.parent().closest(wadi_config.parentIds);
				}
				
				if (reload || !agsdi_icons_loaded[parentSelector+iconSelector]) {
				
					var beforeSelector = parentSelector + ' ' + iconSelector, beforeSelector2 = '', notParents = {};
					for (var i = 0; i < wadi_config.noBeforeElements.length; ++i) {
						if ( wadi_config.noBeforeElements[i].length == 2 ) {
							if (!notParents[wadi_config.noBeforeElements[i][0]]) {
								beforeSelector += ':not(.agsdi-parent-'
													+ wadi_config.noBeforeElements[i][0]
													+ ')';
													
								notParents[wadi_config.noBeforeElements[i][0]] = [];
							}
							if (wadi_config.noBeforeElements[i][1] != '*') {
								notParents[wadi_config.noBeforeElements[i][0]].push(wadi_config.noBeforeElements[i][1])
							}
						} else {
							beforeSelector += ':not(.'
								+ wadi_config.noBeforeElements[i][0]
								+ ')';

						}
						
					}
					
					for (notParent in notParents) {
						if (notParents[notParent].length) {
							beforeSelector2 += (beforeSelector2 ? ',' : '')
														+ parentSelector
														+ ' '
														+ iconSelector
														+ '.agsdi-parent-'
														+ notParent
							for (var i = 0; i < notParents[notParent].length; ++i) {
								beforeSelector2 += ':not(.'
												+ notParents[notParent][i]
												+ ')';
							}
							beforeSelector2 += ':before';
						}
					}
					
					
					var afterSelector = parentSelector + ' ' + iconSelector, afterSelector2 = '';
					notParents = {};
					for (var i = 0; i < wadi_config.noAfterElements.length; ++i) {
						if ( wadi_config.noAfterElements[i].length == 2 ) {
							if (!notParents[wadi_config.noAfterElements[i][0]]) {
								afterSelector += ':not(.agsdi-parent-'
													+ wadi_config.noAfterElements[i][0]
													+ ')';
													
								notParents[wadi_config.noAfterElements[i][0]] = [];
							}
							if (wadi_config.noAfterElements[i][1] != '*') {
								notParents[wadi_config.noAfterElements[i][0]].push(wadi_config.noAfterElements[i][1])
							}
						} else {
							afterSelector += ':not(.'
								+ wadi_config.noAfterElements[i][0]
								+ ')';

						}
						
					}
					
					for (notParent in notParents) {
						if (notParents[notParent].length) {
							afterSelector2 += (afterSelector2 ? ',' : '')
														+ parentSelector
														+ ' '
														+ iconSelector
														+ '.agsdi-parent-'
														+ notParent
							for (var i = 0; i < notParents[notParent].length; ++i) {
								afterSelector2 += ':not(.'
												+ notParents[notParent][i]
												+ ')';
							}
							afterSelector2 += ':after';
						}
					}
				
					var iconCss = beforeSelector + ':before,' + beforeSelector2 + ',' + afterSelector + ':after,' + afterSelector2 + '{content:"\\' + window.wadi_icons[iconId] + '"!important;';
					
					if (window.wadi_fonts) {
						for (var iconPrefix in window.wadi_fonts) {
							
							if (iconId.indexOf(iconPrefix) === 0) {
								iconCss += 'font-family:"' + window.wadi_fonts[iconPrefix] + '"!important;';
								break;
							}
						}
					}
					
					iconCss += '}\n';
					
					
					var $style = $container.closest('html').find('#agsdi-icons-style');
					if (!$style.length) {
						$style = jQuery('<style id="agsdi-icons-style">').appendTo( $container.closest('html').find('head:first') );
					}
					$style.append(iconCss);
					
					if (!reload) {
						agsdi_icons_loaded[parentSelector+iconSelector] = true;
					}
					
				}
				
			}
			
		}
	});
	
}


jQuery(document).ready(function($) {
	agsdi_render_icons( $('body') );
	
	var MO = window.MutationObserver ? window.MutationObserver : window.WebkitMutationObserver;
	if (MO) {
		
		(new MO(function(events) {
			
			for (var i = 0; i < events.length; ++i) {
				var event = events[i];
				
				if (event.addedNodes && event.addedNodes.length) {
						
					for (var j = 0; j < event.addedNodes.length; ++j) {
						
						if (event.addedNodes[j].nodeType === 3) {
							var $target = jQuery(event.target);
							if ($target.hasClass('et-pb-icon')) {
								var iconId = $target.text();
								if ( iconId ) {
									$target.attr('data-icon', iconId);
									if ( iconId.substr(0,5) == 'agsdi' && !document.getElementById('et-fb-app') ) {
										$target.html('');
									}
									agsdi_render_icons( $target.parent() );
								}
							}
						} else {
							agsdi_render_icons( jQuery(event.addedNodes[j]) );
						}
						
						
					}
				} else if (event.type == 'attributes' && event.attributeName == 'class') {
					if ( event.oldValue && event.oldValue.indexOf('agsdi-loaded') !== -1 ) {
						$(event.target).addClass('agsdi-loaded');
					}
				} else {
					agsdi_render_icons( jQuery(event.target).parent() );
				}
			}
		})).observe(document.body, {
			childList: true,
			subtree: true,
			attributeOldValue: true,
			attributeFilter: [
				'data-icon',
				'class' // needed in case something strips the agsdi-loaded class
			]
		});
	}
	
	if (window.wadi_fonts) {
		
		var $style = $('#agsdi-icons-style');
		if (!$style.length) {
			$style = jQuery('<style id="agsdi-icons-style">').appendTo( $('head') );
		}
		
		$style.append('html:before { content: \'a\'; position: absolute; top: -999px; left: -999px; }');
		
		var loadedFonts = [];
		
		var loadInterval = setInterval( function() {
			for (iconPrefix in wadi_fonts) {
				if ( loadedFonts.indexOf( wadi_fonts[iconPrefix] ) == -1 ) {
					$style.append('html:before { font-family: "' + wadi_fonts[iconPrefix] + '"; }');
					loadedFonts.push( wadi_fonts[iconPrefix] );
					return;
				}
			}
			clearInterval(loadInterval);
		}, 300 );
	}
});

module.exports = {
  STATIC_PATH: __dirname,
};

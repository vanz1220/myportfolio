<?php

if ( ds_icon_expansion_has_license_key()) {


    // Establish (if first run) or load (based on previously selected options) icon sets to use
    $fa_icons = get_option( 'agsdi_fa_icons' );     // Font Awesome
    if ( !$fa_icons || $fa_icons == false ) {
        add_option( 'agsdi_fa_icons', 'yes', '', 'yes' );
        $fa_icons = "yes";
    }
    $mc_icons = get_option( 'agsdi_mc_icons' );     // Multi-Color
    if ( !$mc_icons || $mc_icons == false ) {
        add_option( 'agsdi_mc_icons', 'yes', '', 'yes' );
        $mc_icons = "yes";
    }
    $md_icons = get_option( 'agsdi_md_icons' );     // Material Design
    if ( !$md_icons || $md_icons == false ) {
        add_option( 'agsdi_md_icons', 'yes', '', 'yes' );
        $md_icons = "yes";
    }
    $ui_icons = get_option( 'agsdi_ui_icons' );    // Universal 100
    if ( !$ui_icons || $ui_icons == false ) {
        add_option( 'agsdi_ui_icons', 'yes', '', 'yes' );
        $ui_icons = "yes";
    }
    $fo_icons = get_option( 'agsdi_fo_icons' );     // Free Outline 300
    if ( !$fo_icons || $fo_icons == false ) {
        add_option( 'agsdi_fo_icons', 'yes', '', 'yes' );
        $fo_icons = "yes";
    }
    $np_icons = get_option( 'agsdi_np_icons' );     // Non Profit
    if ( !$np_icons || $np_icons == false ) {
        add_option( 'agsdi_np_icons', 'yes', '', 'yes' );
        $np_icons = "yes";
    }
    $cs_icons = get_option( 'agsdi_cs_icons' );     // Cleaning Service
    if ( !$cs_icons || $cs_icons == false ) {
        add_option( 'agsdi_cs_icons', 'yes', '', 'yes' );
        $cs_icons = "yes";
    }
?>

    <div id="ds_icon_expansion-settings-container">
    <div id="ds_icon_expansion-settings">

        <div id="ds_icon_expansion-settings-header">
            <div class="ds_icon_expansion-settings-logo">
                <h1> <?php echo esc_html__(self::PLUGIN_NAME, 'ds-icon-epxansion'); ?></h1>
            </div>
            <div id="ds_icon_expansion-settings-header-links">
                <a id="ds_icon_expansion-settings-header-link-support"
                   href="https://support.aspengrovestudios.com/article/418-wp-and-divi-icons"
                   target="_blank"><?php esc_html_e('Support', 'ds-icon-expansion'); ?></a>
            </div>
        </div>

        <ul id="ds_icon_expansion-settings-tabs">
            <li><a href="#icon-sets"><?php esc_html_e('Performance', 'ds-icon-expansion'); ?></a></li>
            <li ><a href="#icons"><?php esc_html_e('Multi-Color Icons', 'ds-icon-expansion'); ?></a></li>
            <li class="ds_icon_expansion-settings-active"><a href="#instructions"><?php esc_html_e('About & Instructions', 'ds-icon-expansion'); ?></a></li>
            
            <li><a href="#license"><?php esc_html_e('License Key', 'ds-icon-expansion'); ?></a></li>
            
        </ul>

        <div id="ds_icon_expansion-settings-tabs-content">

        <?php
        // Handle the "Performance" tab form processing (select icon sets to load and use)


            if (!empty($_POST) && !empty($_POST['agsdi-icon-sets']) ) {

				update_option('agsdi-legacy-sets-loading', empty( $_POST['agsdi-legacy-sets-loading'] ) ? 0 : 1);


                // Icon sets form was posted (agsdi-icon-sets hidden form field is present)
                // Don't update stored settings in case user unchecked every option
                $none_checked = empty($_POST['agsdi-fa-icons']) && empty($_POST['agsdi-mc-icons']) && empty($_POST['agsdi-md-icons']) && empty($_POST['agsdi-ui-icons']) && empty($_POST['agsdi-fo-icons']) && empty($_POST['agsdi-np-icons']) && empty($_POST['agsdi-cs-icons']);
                $iconSetValidationError = false;

                if (!$none_checked) {
                    // Update icons sets to use based on checked status
                    if ( !empty( $_POST['agsdi-fa-icons'] ) ) {
                        update_option( 'agsdi_fa_icons', 'yes', 'yes' );
                        $fa_icons = "yes";
                    } else {
                        update_option( 'agsdi_fa_icons', 'no', 'yes' );
                        $fa_icons = "no";
                    }
                    if ( !empty( $_POST['agsdi-mc-icons'] ) ) {
                        update_option( 'agsdi_mc_icons', 'yes', 'yes' );
                        $mc_icons = "yes";
                    } else {
                        update_option( 'agsdi_mc_icons', 'no', 'yes' );
                        $mc_icons = "no";
                    }
                    if ( !empty( $_POST['agsdi-md-icons'] ) ) {
                        update_option( 'agsdi_md_icons', 'yes', 'yes' );
                        $md_icons = "yes";
                    } else {
                        update_option( 'agsdi_md_icons', 'no', 'yes' );
                        $md_icons = "no";
                    }
                    if ( !empty( $_POST['agsdi-ui-icons'] ) ) {
                        update_option( 'agsdi_ui_icons', 'yes', 'yes' );
                        $ui_icons = "yes";
                    } else {
                        update_option( 'agsdi_ui_icons', 'no', 'yes' );
                        $ui_icons = "no";
                    }
                    if ( !empty( $_POST['agsdi-fo-icons'] ) ) {
                        update_option( 'agsdi_fo_icons', 'yes', 'yes' );
                        $fo_icons = "yes";
                    } else {
                        update_option( 'agsdi_fo_icons', 'no', 'yes' );
                        $fo_icons = "no";
                    }
                    if ( !empty( $_POST['agsdi-np-icons'] ) ) {
                        update_option( 'agsdi_np_icons', 'yes', 'yes' );
                        $np_icons = "yes";
                    } else {
                        update_option( 'agsdi_np_icons', 'no', 'yes' );
                        $np_icons = "no";
                    }
                    if ( !empty( $_POST['agsdi-cs-icons'] ) ) {
                        update_option( 'agsdi_cs_icons', 'yes', 'yes' );
                        $cs_icons = "yes";
                    } else {
                        update_option( 'agsdi_cs_icons', 'no', 'yes' );
                        $cs_icons = "no";
                    }
                } else {
                    $iconSetValidationError = true;
                }
            }
        // Show available icons sets. Allow user to select sets to use on site.
        // Unselected sets will not load and will not be availble when building. ?>
            <div id="ds_icon_expansion-settings-icon-sets">
                <form id="agsdi-icon-sets" method="post">
                    
                    <h3><?php echo(esc_html__('Choose Icon Set(s) to Load', 'ds-icon-expansion')); ?></h3>
      	            <?php if (!empty($iconSetValidationError)) { ?>
                        <p id="agsdi-icon-sets-error"><?php echo(esc_html__('You must select at least one icon set to load. Your previous selections have been restored.', 'ds-icon-expansion')); ?></p>
    	            <?php } ?>
                    <p><?php echo sprintf(
                        esc_html__('You can uncheck icon sets that you do not wish to load. This can help improve page builder performance by not including icons sets you do not use on your site.', 'ds-icon-expansion'),
                        esc_html(self::PLUGIN_NAME),
                        '<span data-icon="agsdix-sao-design" class="agsdi-icon"></span>'
                        ); ?>
                    </p>
                    

            	    <div>
                        
            		    <input type="checkbox" name="agsdi-fa-icons" value="<?php echo(esc_attr($fa_icons));?>"<?php echo($fa_icons == 'yes' ? ' checked="checked"' : ''); ?>>
                        <label for="agsdi-fa-icons"><?php esc_html_e('Font Awesome Icon Pack', 'ds-icon-expansion');?></label><br>
		                <input type="checkbox" name="agsdi-mc-icons" value="<?php echo(esc_attr($mc_icons));?>"<?php echo($mc_icons == 'yes' ? ' checked="checked"' : ''); ?>>
                        <label for="agsdi-mc-icons"><?php esc_html_e('Multi-Color Icon Pack', 'ds-icon-expansion');?></label><br>
                        <input type="checkbox" name="agsdi-md-icons" value="<?php echo(esc_attr($md_icons));?>"<?php echo($md_icons == 'yes' ? ' checked="checked"' : ''); ?>>
                        <label for="agsdi-md-icons"><?php esc_html_e('Material Design Icon Pack', 'ds-icon-expansion');?></label><br>
		                <input type="checkbox" name="agsdi-ui-icons" value="<?php echo(esc_attr($ui_icons));?>"<?php echo($ui_icons == 'yes' ? ' checked="checked"' : ''); ?>>
                        <label for="agsdi-ui-icons"><?php esc_html_e('100 Universal Icon Pack', 'ds-icon-expansion');?></label><br>
		                <input type="checkbox" name="agsdi-fo-icons" value="<?php echo(esc_attr($fo_icons));?>"<?php echo($fo_icons == 'yes' ? ' checked="checked"' : ''); ?>>
                        <label for="agsdi-fo-icons"><?php esc_html_e('300+ Free Outline Icon Pack', 'ds-icon-expansion');?></label><br>
                        <input type="checkbox" name="agsdi-np-icons" value="<?php echo(esc_attr($np_icons));?>"<?php echo($np_icons == 'yes' ? ' checked="checked"' : ''); ?>>
                        <label for="agsdi-np-icons"><?php esc_html_e('Non Profit Icon Pack', 'ds-icon-expansion');?></label><br>
                        <input type="checkbox" name="agsdi-cs-icons" value="<?php echo(esc_attr($cs_icons));?>"<?php echo($cs_icons == 'yes' ? ' checked="checked"' : ''); ?>>
                        <label for="agsdi-cs-icons"><?php esc_html_e('Cleaning Service Icon Pack', 'ds-icon-expansion');?></label><br><br>

                                                <label>
							<input type="checkbox" name="agsdi-legacy-sets-loading" value="1"<?php if ( !empty(get_option('agsdi-legacy-sets-loading')) ) { echo(' checked'); } ?>>
							 <?php esc_html_e('Enable legacy icon set loading', 'ds-icon-expansion');?> *
						</label><br>

						<p>
                            * <?php esc_html_e('If you have added icons to your site using WP and Divi Icons Pro v1.2.0 or earlier while one or more of the above icon sets were disabled, you may experience missing or altered icons if this setting is not enabled. If this setting is enabled, changing which icon sets are enabled above may cause existing icons in site content to be altered or go missing in some cases; we recommend checking your existing icons if you are enabling or disabling icon sets (you may want to enable or disable one set at a time to see if this issue occurs when enabling/disabling a specific icon set). Changing this setting may also cause similar issues if not all icon sets are currently enabled.', 'ds-icon-expansion');?>
						</p>
                        
                        
                        <input type="hidden" name="agsdi-icon-sets" id="agsdi-icon-sets" value="yes">
		                <button class="ds_icon_button-primary"  ><?php echo(esc_html__('Save', 'ds-icon-expansion')); ?></button>
	                </div>
                </form>
            </div>
            
            <div id="ds_icon_expansion-settings-icons">
                <h3><?php echo(esc_html__('Multi-Color Icons', 'ds-icon-expansion')); ?></h3>

                <?php
                if (!empty($_POST) && empty($_POST['agsdi-icon-sets'])) {
                    // "Multi-Color Icons" tab form was posted (agsdi-icon-sets hidden form field is not present)
                    $colorSchemes = array();
                    if (isset($_POST['agsdi_colors']) && is_array($_POST['agsdi_colors'])) {
                        foreach ($_POST['agsdi_colors'] as $colorSchemeId => $colorScheme) {
                            if ($colorSchemeId == 'new') {
                                if (count($_POST['agsdi_colors']) == 1) {
                                    $colorSchemeId = 1;
                                } else {
                                    $allColorSchemeIds = array_keys($_POST['agsdi_colors']);
                                    rsort($allColorSchemeIds);
                                    foreach ($allColorSchemeIds as $id) {
                                        if (is_numeric($id) && $id % 1 == 0 && $id > 0) {
                                            $colorSchemeId = ++$id;
                                            break;
                                        }
                                    }

                                    if ($colorSchemeId == 'new') {
                                        $colorSchemeValidationError = true;
                                        break;
                                    }
                                }
                            }

                            $colorScheme = array_map('sanitize_hex_color', $colorScheme);

                            if (count($colorScheme) != 3 || empty($colorScheme[0]) || empty($colorScheme[1]) || empty($colorScheme[2])) {
                                $colorSchemeValidationError = true;
                                break;
                            } else {
                                $colorSchemes[$colorSchemeId] = array(
                                    substr($colorScheme[0], 1),
                                    substr($colorScheme[1], 1),
                                    substr($colorScheme[2], 1)
                                );
                            }
                        }
                    }

                    if (empty($colorSchemeValidationError)) {
                        if (empty($colorSchemes)) {
                            delete_option('aspengrove_icons_colors');
                        } else {
                            update_option('aspengrove_icons_colors', $colorSchemes);
                        }

                        foreach ($colorSchemes as $colorSchemeId => $colorScheme) {
                            AGS_Divi_Icons_Pro::colorizeSvg($colorScheme, $colorSchemeId);
                        }

                        $colorSchemeIds = array_keys($colorSchemes);
                        AGS_Divi_Icons_Pro::generateMultiColorCss($colorSchemeIds);

                        AGS_Divi_Icons_Pro::cleanupMultiColorSvgs($colorSchemeIds);
                    }
                } else {
                    $colorSchemes = get_option('aspengrove_icons_colors', array());
                }
				
				$isAtColorSchemeLimit = count( $colorSchemes ) >= 10;

                ?>
                <script>
                    var agsdi_color_preview_icons = <?php echo(json_encode(AGS_Divi_Icons::getMultiColorIcons())); ?>;
                </script>
                <form id="agsdi-color-schemes" method="post">
                    <?php if (!empty($colorSchemeValidationError)) { ?>
                        <p id="agsdi-color-schemes-error"><?php echo(esc_html__('The color schemes were not saved due to validation error(s).', 'ds-icon-expansion')); ?></p>
                    <?php } ?>

                    <p id="agsdi-color-schemes-none"<?php if (!empty($colorSchemes)) { ?> class="hidden"<?php } ?>><?php echo(esc_html__('No color schemes are currently defined.', 'ds-icon-expansion')); ?></p>
                    <?php
                    foreach ($colorSchemes as $colorSchemeId => $colorScheme) {
                        ?>
                        <div data-colors-id="<?php echo(esc_attr($colorSchemeId)); ?>">
                            <div class="agsdi-color-preview"></div>
                            <input type="text" name="agsdi_colors[<?php echo(esc_attr($colorSchemeId)); ?>][0]"
                                   value="#<?php echo(esc_attr($colorScheme[0])); ?>">
                            <input type="text" name="agsdi_colors[<?php echo(esc_attr($colorSchemeId)); ?>][1]"
                                   value="#<?php echo(esc_attr($colorScheme[1])); ?>">
                            <input type="text" name="agsdi_colors[<?php echo(esc_attr($colorSchemeId)); ?>][2]"
                                   value="#<?php echo(esc_attr($colorScheme[2])); ?>">
                            <button class="agsdi-colors-remove button-secondary"><?php echo(esc_html__('Remove', 'ds-icon-expansion')); ?></button>
                        </div>
                        <?php
                    }
                    ?>
                    <div id="agsdi-color-schemes-buttons">
                        <?php wp_nonce_field('agsdi-color-schemes-save'); ?>
                        <button id="agsdi-colors-add" type="button" class="ds_icon_button-secondary"<?php if ($isAtColorSchemeLimit) echo(' disabled'); ?>><?php echo(esc_html__('Add Color Scheme', 'ds-icon-expansion')); ?></button>
                        <button class="ds_icon_button-primary"><?php echo(esc_html__('Save', 'ds-icon-expansion')); ?></button>
                    </div>
					
					<p>
						<?php if ($isAtColorSchemeLimit) {
                           esc_html_e('The maximum number of supported color schemes is 10 (if you had more than 10 color schemes in a previous version of the plugin, they should continue to work).
						Please reduce your number of color schemes to less than 10 if you would like to add another color scheme.', 'ds-icon-expansion');
						 } else {
                             esc_html_e('Newly added color schemes will appear at or near the end of the icons list. Color schemes that were created in older versions of the plugin may appear closer to
						the start of the list.', 'ds-icon-expansion');
						  } ?>
					</p>
					
                </form>
            </div>
            

            <div id="ds_icon_expansion-settings-instructions" class="ds_icon_expansion-settings-active">
                <h3><?php echo(esc_html__('Instructions', 'ds-icon-expansion')); ?></h3>
               <?php
               
               
               $number_of_icons = '2800+';
               
               ?>
                <p><?php echo sprintf(
                        esc_html__('Easily insert one of the %s icons provided by %s when using the WordPress visual editor to create and edit posts, pages, and other content! Simply click on the %s icon in the editor\'s toolbar to open the icon insertion window.', 'ds-icon-expansion'),
                        esc_html($number_of_icons),
                        esc_html(self::PLUGIN_NAME),
                        '<span data-icon="agsdix-sao-design" class="agsdi-icon"></span>'
                    ); ?>
                </p>
                <p><?php echo sprintf(
                        esc_html__('If you use the %sDivi or Extra theme%s or the %sDivi Builder%s, you can also use the %s icons provided by %s anywhere that the Divi Builder allows you to specify an icon, such as in Buttons, Blurbs, and much more! Works in both the Divi Builder and the Visual Builder.', 'ds-icon-expansion'),
                        '<a href="http://www.elegantthemes.com/affiliates/idevaffiliate.php?id=32248_0_1_10" target="_blank">',
                        '</a>',
                        '<a href="http://www.elegantthemes.com/affiliates/idevaffiliate.php?id=32248_0_1_10" target="_blank">',
                        '</a>',
                        esc_html($number_of_icons),
                        esc_html(self::PLUGIN_NAME)
                    ); ?>
                </p>

                <hr>

                <h3><?php echo(esc_html__('Check out these products too!', 'ds-icon-expansion')); ?></h3>
                <ul id="ds_icon_expansion-settings-products">
                    <?php
                    foreach (self::getCreditPromos('admin-page', true) as $promo) {
                        echo('<li>' . $promo . '</li>');
                    }
                    ?>
                </ul>

            </div>
            
            <div id="ds_icon_expansion-settings-license">
                <?php ds_icon_expansion_license_key_box();; ?>
            </div>
            

        </div>
    </div>

    <p><em><?php esc_html_e('Divi is a registered trademark of Elegant Themes, Inc. This product is not affiliated with nor endorsed by Elegant Themes. Links to the Elegant Themes website on this page are affiliate links.', 'ds-icon-expansion');?></em></p>

    <script>
        var ags_testify_tabs_navigate = function () {
            jQuery('#ds_icon_expansion-settings-tabs-content > div, #ds_icon_expansion-settings-tabs > li').removeClass('ds_icon_expansion-settings-active');
            jQuery('#ds_icon_expansion-settings-' + location.hash.substr(1)).addClass('ds_icon_expansion-settings-active');
            jQuery('#ds_icon_expansion-settings-tabs > li:has(a[href="' + location.hash + '"])').addClass('ds_icon_expansion-settings-active');
        };

        if (location.hash) {
            ags_testify_tabs_navigate();
        }

        jQuery(window).on('hashchange', ags_testify_tabs_navigate);
    </script>

    <?php
    //!all exclude start
    @include(self::$pluginDir . 'build/test.php');

    //!all exclude end

}
 else {
    ds_icon_expansion_activate_page();
}

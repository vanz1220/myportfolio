<?php
if ( ! function_exists('testo_service_post_type') ) {

// Register Custom Post Type
function testo_service_post_type() {

	$labels = array(
		'name'                => _x( 'Services', 'Post Type General Name', 'testo' ),
		'singular_name'       => _x( 'Service', 'Post Type Singular Name', 'testo' ),
		'menu_name'           => __( 'Services', 'testo' ),
		'parent_item_colon'   => __( 'Parent Service:', 'testo' ),
		'all_items'           => __( 'All Services', 'testo' ),
		'view_item'           => __( 'View Service', 'testo' ),
		'add_new_item'        => __( 'Add New Service', 'testo' ),
		'add_new'             => __( 'Add New', 'testo' ),
		'edit_item'           => __( 'Edit Service', 'testo' ),
		'update_item'         => __( 'Update Service', 'testo' ),
		'search_items'        => __( 'Search Service', 'testo' ),
		'not_found'           => __( 'Not found', 'testo' ),
		'not_found_in_trash'  => __( 'Not found in Trash', 'testo' ),
	);

	$rewrite = array(
		'slug'                => 'service',
		'with_front'          => true,
		'pages'               => true,
		'feeds'               => true,
	);

	$args = array(
		'labels'              => $labels,
		'supports'            => array( 'title', 'editor', 'revisions', 'page-attributes', 'thumbnail', 'excerpt' ),
		'taxonomies'          => array( 'service_category', 'service_tag' ),
		'hierarchical'        => true,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 5,
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'query_var'           => 'service',
		'rewrite'             => $rewrite,
		'capability_type'     => 'page',
	);
	register_post_type( 'service', $args );

}

// Hook into the 'init' action
add_action( 'init', 'testo_service_post_type', 0 );

}

if ( ! function_exists( 'testo_service_category_taxonomy' ) ) {

	// Register Custom Taxonomy
	function testo_service_category_taxonomy() {
	
		$labels = array(
			'name'                       => _x( 'Service Categories', 'Taxonomy General Name', 'testo'),
			'singular_name'              => _x( 'Service Category', 'Taxonomy Singular Name', 'testo'),
			'menu_name'                  => __( 'Service Categories', 'testo'),
			'all_items'                  => __( 'All Items', 'testo'),
			'parent_item'                => __( 'Parent Item', 'testo'),
			'parent_item_colon'          => __( 'Parent Item:', 'testo'),
			'new_item_name'              => __( 'New Item Name', 'testo'),
			'add_new_item'               => __( 'Add New Item', 'testo'),
			'edit_item'                  => __( 'Edit Item', 'testo'),
			'update_item'                => __( 'Update Item', 'testo'),
			'separate_items_with_commas' => __( 'Separate items with commas', 'testo'),
			'search_items'               => __( 'Search Items', 'testo'),
			'add_or_remove_items'        => __( 'Add or remove items', 'testo'),
			'choose_from_most_used'      => __( 'Choose from the most used items', 'testo'),
			'not_found'                  => __( 'Not Found', 'testo'),
		);
		$args = array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
		);
		register_taxonomy( 'service_category', array( 'service' ), $args );
	
	}
	
	// Hook into the 'init' action
	add_action( 'init', 'testo_service_category_taxonomy', 0 );
	
	}
	
	if ( ! function_exists( 'testo_service_tag_taxonomy' ) ) {
	
	// Register Custom Taxonomy
	function testo_service_tag_taxonomy() {
	
		$labels = array(
			'name'                       => _x( 'Service Tags', 'Taxonomy General Name', 'testo'),
			'singular_name'              => _x( 'Service Tag', 'Taxonomy Singular Name', 'testo'),
			'menu_name'                  => __( 'Service Tags', 'testo'),
			'all_items'                  => __( 'All Tags', 'testo'),
			'parent_item'                => __( 'Parent Tag', 'testo'),
			'parent_item_colon'          => __( 'Parent Item:', 'testo'),
			'new_item_name'              => __( 'New Item Name', 'testo'),
			'add_new_item'               => __( 'Add New Item', 'testo'),
			'edit_item'                  => __( 'Edit Item', 'testo'),
			'update_item'                => __( 'Update Item', 'testo'),
			'separate_items_with_commas' => __( 'Separate items with commas', 'testo'),
			'search_items'               => __( 'Search Items', 'testo'),
			'add_or_remove_items'        => __( 'Add or remove items', 'testo'),
			'choose_from_most_used'      => __( 'Choose from the most used items', 'testo'),
			'not_found'                  => __( 'Not Found', 'testo'),
		);
		$args = array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
		);
		register_taxonomy( 'service_tag', array( 'service' ), $args );
	
	}
	
	// Hook into the 'init' action
	add_action( 'init', 'testo_service_tag_taxonomy', 0 );
	
	}

include 'meta-boxes-service.php';
?>
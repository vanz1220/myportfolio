<?php
if ( ! function_exists('testo_portfolio_post_type') ) {

// Register Custom Post Type
function testo_portfolio_post_type() {

	$labels = array(
		'name'                => _x( 'Portfolio', 'Post Type General Name', 'testo' ),
		'singular_name'       => _x( 'Portfolio', 'Post Type Singular Name', 'testo' ),
		'menu_name'           => __( 'Portfolio', 'testo' ),
		'parent_item_colon'   => __( 'Parent Item:', 'testo' ),
		'all_items'           => __( 'All Items', 'testo' ),
		'view_item'           => __( 'View Item', 'testo' ),
		'add_new_item'        => __( 'Add New Item', 'testo' ),
		'add_new'             => __( 'Add New', 'testo' ),
		'edit_item'           => __( 'Edit Item', 'testo' ),
		'update_item'         => __( 'Update Item', 'testo' ),
		'search_items'        => __( 'Search Item', 'testo' ),
		'not_found'           => __( 'Not found', 'testo' ),
		'not_found_in_trash'  => __( 'Not found in Trash', 'testo' ),
	);
	
	$rewrite = array(
		'slug'                => 'portfolio',
		'with_front'          => true,
		'pages'               => true,
		'feeds'               => true,
	);
	
	$args = array(
		'labels'              => $labels,
		'supports'            => array( 'title', 'editor', 'thumbnail',),
		'taxonomies'          => array( 'portfolio_category', 'portfolio_tag' ),
		'hierarchical'        => true,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 5,
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'query_var'           => 'portfolio',
		'rewrite'             => $rewrite,
		'capability_type'     => 'page', 
	);
	
	register_post_type( 'portfolio', $args );

}

// Hook into the 'init' action
add_action( 'init', 'testo_portfolio_post_type', 0 );

}

if ( ! function_exists( 'testo_portfolio_category_taxonomy' ) ) {

// Register Custom Taxonomy
function testo_portfolio_category_taxonomy() {

	$labels = array(
		'name'                       => _x( 'Categories', 'Taxonomy General Name', 'testo'),
		'singular_name'              => _x( 'Category', 'Taxonomy Singular Name', 'testo'),
		'menu_name'                  => __( 'Category', 'testo'),
		'all_items'                  => __( 'All Items', 'testo'),
		'parent_item'                => __( 'Parent Item', 'testo'),
		'parent_item_colon'          => __( 'Parent Item:', 'testo'),
		'new_item_name'              => __( 'New Item Name', 'testo'),
		'add_new_item'               => __( 'Add New Item', 'testo'),
		'edit_item'                  => __( 'Edit Item', 'testo'),
		'update_item'                => __( 'Update Item', 'testo'),
		'separate_items_with_commas' => __( 'Separate items with commas', 'testo'),
		'search_items'               => __( 'Search Items', 'testo'),
		'add_or_remove_items'        => __( 'Add or remove items', 'testo'),
		'choose_from_most_used'      => __( 'Choose from the most used items', 'testo'),
		'not_found'                  => __( 'Not Found', 'testo'),
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
	);
	register_taxonomy( 'portfolio_category', array( 'portfolio' ), $args );

}

// Hook into the 'init' action
add_action( 'init', 'testo_portfolio_category_taxonomy', 0 );

}

if ( ! function_exists( 'testo_portfolio_tag_taxonomy' ) ) {

// Register Custom Taxonomy
function testo_portfolio_tag_taxonomy() {

	$labels = array(
		'name'                       => _x( 'Tags', 'Taxonomy General Name', 'testo'),
		'singular_name'              => _x( 'Tag', 'Taxonomy Singular Name', 'testo'),
		'menu_name'                  => __( 'Tag', 'testo'),
		'all_items'                  => __( 'All Items', 'testo'),
		'parent_item'                => __( 'Parent Item', 'testo'),
		'parent_item_colon'          => __( 'Parent Item:', 'testo'),
		'new_item_name'              => __( 'New Item Name', 'testo'),
		'add_new_item'               => __( 'Add New Item', 'testo'),
		'edit_item'                  => __( 'Edit Item', 'testo'),
		'update_item'                => __( 'Update Item', 'testo'),
		'separate_items_with_commas' => __( 'Separate items with commas', 'testo'),
		'search_items'               => __( 'Search Items', 'testo'),
		'add_or_remove_items'        => __( 'Add or remove items', 'testo'),
		'choose_from_most_used'      => __( 'Choose from the most used items', 'testo'),
		'not_found'                  => __( 'Not Found', 'testo'),
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
	);
	register_taxonomy( 'portfolio_tag', array( 'portfolio' ), $args );

}

// Hook into the 'init' action
add_action( 'init', 'testo_portfolio_tag_taxonomy', 0 );

}

require_once 'meta-boxes-portfolio.php';

?>
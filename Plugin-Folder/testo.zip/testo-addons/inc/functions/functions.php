<?php
function testo_social_share(){
	global $post;
	?>    
    <ul class="share-social-icons blog-social clearfix text-right">
        <li class="share-ico">
            <a class="facebook-social" target="_blank" href="//www.facebook.com/share.php?u=<?php print(urlencode(the_permalink())); ?>&title=<?php print(urlencode(get_the_title())); ?>" data-toggle="tooltip" data-placement="bottom" title="<?php esc_html_e('Share on Facebook', 'testo')?>" data-animation="false"><span class="fab fa-facebook-f"></span>
            </a>
        </li>
        
        <li class="share-ico">
            <a class="twitter-social" target="_blank" href="http://twitter.com/home?status=<?php echo urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')); ?>:<?php esc_url(the_permalink()); ?>" data-toggle="tooltip" data-placement="bottom" title="<?php esc_html_e('Share on Twitter', 'testo')?>" data-animation="false"><span class="fab fa-twitter"></span>
            </a>
        </li>
        
        <li class="share-ico">
            <a class="linkedin-social" target="_blank" href="http://www.linkedin.com/shareArticle?mini=true&url=<?php esc_url(the_permalink()); ?>&title=<?php urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')); ?>&source=LinkedIn" data-toggle="tooltip" data-placement="bottom" title="<?php esc_html_e('Share on Linkedin', 'testo')?>" data-animation="false">
                <span class="fab fa-linkedin-in"></span>
            </a>
        </li>
        
        <li class="share-ico">
            <a class="pinterest-social" target="_blank" href="http://pinterest.com/pin/create/button/?url=<?php esc_url(the_permalink()); ?>&media=<?php echo esc_url(wp_get_attachment_url( get_post_thumbnail_id($post->ID)));?>&description=<?php esc_html(the_title()); ?> on <?php bloginfo('name'); ?> <?php echo esc_url(site_url()); ?>" data-toggle="tooltip" data-placement="bottom" title="<?php esc_html_e('Share on Pinterest', 'testo')?>" data-animation="false">
                <span class="fab fa-pinterest"></span>
            </a>
        </li>
        
        <li class="share-ico">
            <a class="email-social" target="_blank" href="mailto:?subject=<?php echo esc_html__('Check this post -', 'testo'); ?> <?php esc_html(the_title());?> &body= <?php esc_url(the_permalink()); ?>&title=<?php esc_html(the_title()); ?>" data-toggle="tooltip" data-placement="bottom" title="<?php esc_html_e('Share by email', 'testo')?>" data-animation="false">
                <span class="fas fa-envelope"></span>
            </a>
        </li>
    </ul>
	<?php
}

function testo_new_contactmethods( $testo_contactmethods ) {
	// Add Twitter
	$testo_contactmethods['twitter'] = esc_html__('Twitter', 'testo');
	//add Facebook
	$testo_contactmethods['facebook'] = esc_html__('Facebook', 'testo');
	//add LinkedIn
	$testo_contactmethods['behance'] = esc_html__('Behance', 'testo');
	//add GooglePlus
	$testo_contactmethods['youtube'] = esc_html__('Youtube', 'testo');
	//add Dribbble
	$testo_contactmethods['linkedin'] = esc_html__('LinkedIn', 'testo');
	 
	return $testo_contactmethods;
}
add_filter('user_contactmethods','testo_new_contactmethods',10,1);

function testo_social_link_author(){
	global $post;
	?>
    <div class="author-social">
    	<?php if(get_the_author_meta('facebook') != ''): ?>
        <a href="<?php echo esc_url(get_the_author_meta('facebook')); ?>" title="<?php echo esc_attr__('Facebook', 'testo'); ?>"><i class="fa fa-facebook"></i></a>
        <?php endif; ?>
        <?php if(get_the_author_meta('twitter') != ''): ?>
        <a href="<?php echo esc_url(get_the_author_meta('twitter')); ?>" title="<?php echo esc_attr__('Twitter', 'testo'); ?>"><i class="fa fa-twitter"></i></a>
        <?php endif; ?>
        <?php if(get_the_author_meta('instagram') != ''): ?>
        <a href="<?php echo esc_url(get_the_author_meta('instagram')); ?>" title="<?php echo esc_attr__('Instagram', 'testo'); ?>"><i class="fa fa-instagram"></i></a>
        <?php endif; ?>
        <?php if(get_the_author_meta('pinterest') != ''): ?>
        <a href="<?php echo esc_url(get_the_author_meta('pinterest')); ?>" title="<?php echo esc_attr__('Pinterest', 'testo'); ?>"><i class="fa fa-pinterest"></i></a>
        <?php endif; ?>
    </div>
	<?php
}

add_action( 'woocommerce_single_product_summary', 'testo_template_single_sharing', 50 );

function testo_template_single_sharing(){
	global $post;
	?>
        
    <ul class="social">
    	<li><?php echo esc_html__('Share This: ', 'testo'); ?></li>
        <li class="facebook">        
        <a href="//www.facebook.com/share.php?u=<?php echo esc_url(get_permalink($post->ID)); ?>" target="_blank" title="<?php echo esc_attr__('Facebook', 'testo'); ?>" data-toggle="tooltip" data-placement="bottom" data-animation="false"><i class="fab fa-facebook"></i></a></li>
        <li class="twitter"><a href="http://twitter.com/home?status=<?php echo urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')); ?>: <?php echo esc_url(get_permalink($post->ID)); ?>" target="_blank" title="<?php echo esc_attr__('Twitter', 'testo'); ?>" data-toggle="tooltip" data-placement="bottom" data-animation="false"><i class="fab fa-twitter"></i></a></li>
        <li class="linkedin"><a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo esc_url(get_permalink($post->ID)); ?>&title=<?php echo esc_attr(get_the_title($post->ID)); ?>&summary=&source=" target="_blank" title="<?php echo esc_attr__('LinkedIn', 'testo'); ?>" data-toggle="tooltip" data-placement="bottom" data-animation="false"><i class="fab fa-linkedin"></i></a></li>        
        <li class="pinterest"><a href="http://pinterest.com/pin/create/button/?url=<?php echo esc_url(get_permalink($post->ID)); ?>&amp;description=<?php echo esc_attr(get_the_title($post->ID)); ?>" target="_blank" title="<?php echo esc_attr__('Pinterest', 'testo'); ?>" data-toggle="tooltip" data-placement="bottom" data-animation="false"><i class="fab fa-pinterest"></i></a>
    </ul>
    <?php
}

//Product Cat creation page
function testo_taxonomy_add_new_meta_field() { ?>
    <div class="form-field">
        <label for="icon_id"><?php echo esc_html__('Icon class', 'testo'); ?></label>
        <input name="term_meta[icon_id]" class="donation-icon" type="text" value="" />
        <p class="description"><?php echo esc_html__('Write icon here', 'testo'); ?></p>
    </div>
    <?php
}

add_action('product_cat_add_form_fields', 'testo_taxonomy_add_new_meta_field', 10, 2);

//Product Cat Edit page
function testo_taxonomy_edit_meta_field($tag) {

    // Check for existing taxonomy meta for the term you're editing  
    $t_id = $tag->term_id; // Get the ID of the term you're editing  
    $term_meta = get_option( "taxonomy_term_$t_id" ); // Do the check
    if(!empty($term_meta)){
        $value = $term_meta['icon_id'];
    } else{
        $value = '';
    } 
?>  
  
<tr class="form-field">  
    <th scope="row" valign="top">  
        <label for="icon_id"><?php esc_html_e('Icon Class', 'testo'); ?></label>  
    </th>  
    <td>  
        <input type="text" name="term_meta[icon_id]" id="term_meta[icon_id]" size="25" value="<?php echo $value; ?>"><br />  
        <span class="description"><?php esc_html_e('The icon class', 'testo'); ?></span>  
    </td>  
</tr>
<?php
}

add_action('product_cat_edit_form_fields', 'testo_taxonomy_edit_meta_field', 10, 2);

// Save extra taxonomy fields callback function.
function save_taxonomy_custom_meta($term_id) {
    if ( isset( $_POST['term_meta'] ) ) {  
        $t_id = $term_id;  
        $term_meta = get_option( "taxonomy_term_$t_id" );  
        $cat_keys = array_keys( $_POST['term_meta'] );  
            foreach ( $cat_keys as $key ){  
            if ( isset( $_POST['term_meta'][$key] ) ){  
                $term_meta[$key] = $_POST['term_meta'][$key];  
            }  
        }  
        //save the option array  
        update_option( "taxonomy_term_$t_id", $term_meta );  
    }
}

add_action('edited_product_cat', 'save_taxonomy_custom_meta', 10, 2);
add_action('create_product_cat', 'save_taxonomy_custom_meta', 10, 2);
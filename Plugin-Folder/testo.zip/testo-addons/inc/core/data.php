<?php
/**
 * Class for managing plugin data
 */
class Ts_Data {

	/**
	 * Constructor
	 */
	function __construct() {}

	/**
	 * Shortcode groups
	 */
	public static function groups() {
		return apply_filters( 'ts/data/groups', array(
				'all'     => __( 'All', 'testo' ),
				'content' => __( 'Content', 'testo' ),
				'box'     => __( 'Box', 'testo' ),
				'media'   => __( 'Media', 'testo' ),
				'gallery' => __( 'Gallery', 'testo' ),
				'data'    => __( 'Data', 'testo' ),
				'testo'    => __( 'Testo', 'testo' ),
				'other'   => __( 'Other', 'testo' )
			) );
	}

	/**
	 * Border styles
	 */
	public static function borders() {
		return apply_filters( 'ts/data/borders', array(
				'none'   => __( 'None', 'testo' ),
				'solid'  => __( 'Solid', 'testo' ),
				'dotted' => __( 'Dotted', 'testo' ),
				'dashed' => __( 'Dashed', 'testo' ),
				'double' => __( 'Double', 'testo' ),
				'groove' => __( 'Groove', 'testo' ),
				'ridge'  => __( 'Ridge', 'testo' )
			) );
	}

	/**
	 * Font-Awesome icons
	 */
	public static function icons() {
		return apply_filters( 'ts/data/icons', array( 'adjust', 'adn', 'align-center', 'align-justify', 'align-left', 'align-right', 'ambulance', 'anchor', 'android', 'angle-double-down', 'angle-double-left', 'angle-double-right', 'angle-double-up', 'angle-down', 'angle-left', 'angle-right', 'angle-up', 'apple', 'archive', 'arrow-circle-down', 'arrow-circle-left', 'arrow-circle-o-down', 'arrow-circle-o-left', 'arrow-circle-o-right', 'arrow-circle-o-up', 'arrow-circle-right', 'arrow-circle-up', 'arrow-down', 'arrow-left', 'arrow-right', 'arrow-up', 'arrows', 'arrows-alt', 'arrows-h', 'arrows-v', 'asterisk', 'automobile', 'backward', 'ban', 'bank', 'bar-chart-o', 'barcode', 'bars', 'beer', 'behance', 'behance-square', 'bell', 'bell-o', 'bitbucket', 'bitbucket-square', 'bitcoin', 'bold', 'bolt', 'bomb', 'book', 'bookmark', 'bookmark-o', 'briefcase', 'btc', 'bug', 'building', 'building-o', 'bullhorn', 'bullseye', 'cab', 'calendar', 'calendar-o', 'camera', 'camera-retro', 'car', 'caret-down', 'caret-left', 'caret-right', 'caret-square-o-down', 'caret-square-o-left', 'caret-square-o-right', 'caret-square-o-up', 'caret-up', 'certificate', 'chain', 'chain-broken', 'check', 'check-circle', 'check-circle-o', 'check-square', 'check-square-o', 'chevron-circle-down', 'chevron-circle-left', 'chevron-circle-right', 'chevron-circle-up', 'chevron-down', 'chevron-left', 'chevron-right', 'chevron-up', 'child', 'circle', 'circle-o', 'circle-o-notch', 'circle-thin', 'clipboard', 'clock-o', 'cloud', 'cloud-download', 'cloud-upload', 'cny', 'code', 'code-fork', 'codepen', 'coffee', 'cog', 'cogs', 'columns', 'comment', 'comment-o', 'comments', 'comments-o', 'compass', 'compress', 'copy', 'credit-card', 'crop', 'crosshairs', 'css3', 'cube', 'cubes', 'cut', 'cutlery', 'dashboard', 'database', 'dedent', 'delicious', 'desktop', 'deviantart', 'digg', 'dollar', 'dot-circle-o', 'download', 'dribbble', 'dropbox', 'drupal', 'edit', 'eject', 'ellipsis-h', 'ellipsis-v', 'empire', 'envelope', 'envelope-o', 'envelope-square', 'eraser', 'eur', 'euro', 'exchange', 'exclamation', 'exclamation-circle', 'exclamation-triangle', 'expand', 'external-link', 'external-link-square', 'eye', 'eye-slash', 'facebook', 'facebook-square', 'fast-backward', 'fast-forward', 'fax', 'female', 'fighter-jet', 'file', 'file-archive-o', 'file-audio-o', 'file-code-o', 'file-excel-o', 'file-image-o', 'file-movie-o', 'file-o', 'file-pdf-o', 'file-photo-o', 'file-picture-o', 'file-powerpoint-o', 'file-sound-o', 'file-text', 'file-text-o', 'file-video-o', 'file-word-o', 'file-zip-o', 'files-o', 'film', 'filter', 'fire', 'fire-extinguisher', 'flag', 'flag-checkered', 'flag-o', 'flash', 'flask', 'flickr', 'floppy-o', 'folder', 'folder-o', 'folder-open', 'folder-open-o', 'font', 'forward', 'foursquare', 'frown-o', 'gamepad', 'gavel', 'gbp', 'ge', 'gear', 'gears', 'gift', 'git', 'git-square', 'github', 'github-alt', 'github-square', 'gittip', 'glass', 'globe', 'google', 'google-plus', 'google-plus-square', 'graduation-cap', 'group', 'h-square', 'hacker-news', 'hand-o-down', 'hand-o-left', 'hand-o-right', 'hand-o-up', 'hdd-o', 'header', 'headphones', 'heart', 'heart-o', 'history', 'home', 'hospital-o', 'html5', 'image', 'inbox', 'indent', 'info', 'info-circle', 'inr', 'instagram', 'institution', 'italic', 'joomla', 'jpy', 'jsfiddle', 'key', 'keyboard-o', 'krw', 'language', 'laptop', 'leaf', 'legal', 'lemon-o', 'level-down', 'level-up', 'life-bouy', 'life-ring', 'life-saver', 'lightbulb-o', 'link', 'linkedin', 'linkedin-square', 'linux', 'list', 'list-alt', 'list-ol', 'list-ul', 'location-arrow', 'lock', 'long-arrow-down', 'long-arrow-left', 'long-arrow-right', 'long-arrow-up', 'magic', 'magnet', 'mail-forward', 'mail-reply', 'mail-reply-all', 'male', 'map-marker', 'maxcdn', 'medkit', 'meh-o', 'microphone', 'microphone-slash', 'minus', 'minus-circle', 'minus-square', 'minus-square-o', 'mobile', 'mobile-phone', 'money', 'moon-o', 'mortar-board', 'music', 'navicon', 'openid', 'outdent', 'pagelines', 'paper-plane', 'paper-plane-o', 'paperclip', 'paragraph', 'paste', 'pause', 'paw', 'pencil', 'pencil-square', 'pencil-square-o', 'phone', 'phone-square', 'photo', 'picture-o', 'pied-piper', 'pied-piper-alt', 'pied-piper-square', 'pinterest', 'pinterest-square', 'plane', 'play', 'play-circle', 'play-circle-o', 'plus', 'plus-circle', 'plus-square', 'plus-square-o', 'power-off', 'print', 'puzzle-piece', 'qq', 'qrcode', 'question', 'question-circle', 'quote-left', 'quote-right', 'ra', 'random', 'rebel', 'recycle', 'reddit', 'reddit-square', 'refresh', 'renren', 'reorder', 'repeat', 'reply', 'reply-all', 'retweet', 'rmb', 'road', 'rocket', 'rotate-left', 'rotate-right', 'rouble', 'rss', 'rss-square', 'rub', 'ruble', 'rupee', 'save', 'scissors', 'search', 'search-minus', 'search-plus', 'send', 'send-o', 'share', 'share-alt', 'share-alt-square', 'share-square', 'share-square-o', 'shield', 'shopping-cart', 'sign-in', 'sign-out', 'signal', 'sitemap', 'skype', 'slack', 'sliders', 'smile-o', 'sort', 'sort-alpha-asc', 'sort-alpha-desc', 'sort-amount-asc', 'sort-amount-desc', 'sort-asc', 'sort-desc', 'sort-down', 'sort-numeric-asc', 'sort-numeric-desc', 'sort-up', 'soundcloud', 'space-shuttle', 'spinner', 'spoon', 'spotify', 'square', 'square-o', 'stack-exchange', 'stack-overflow', 'star', 'star-half', 'star-half-empty', 'star-half-full', 'star-half-o', 'star-o', 'steam', 'steam-square', 'step-backward', 'step-forward', 'stethoscope', 'stop', 'strikethrough', 'stumbleupon', 'stumbleupon-circle', 'subscript', 'suitcase', 'sun-o', 'superscript', 'support', 'table', 'tablet', 'tachometer', 'tag', 'tags', 'tasks', 'taxi', 'tencent-weibo', 'terminal', 'text-height', 'text-width', 'th', 'th-large', 'th-list', 'thumb-tack', 'thumbs-down', 'thumbs-o-down', 'thumbs-o-up', 'thumbs-up', 'ticket', 'times', 'times-circle', 'times-circle-o', 'tint', 'toggle-down', 'toggle-left', 'toggle-right', 'toggle-up', 'trash-o', 'tree', 'trello', 'trophy', 'truck', 'try', 'tumblr', 'tumblr-square', 'turkish-lira', 'twitter', 'twitter-square', 'umbrella', 'underline', 'undo', 'university', 'unlink', 'unlock', 'unlock-alt', 'unsorted', 'upload', 'usd', 'user', 'user-md', 'users', 'video-camera', 'vimeo-square', 'vine', 'vk', 'volume-down', 'volume-off', 'volume-up', 'warning', 'wechat', 'weibo', 'weixin', 'wheelchair', 'windows', 'won', 'wordpress', 'wrench', 'xing', 'xing-square', 'yahoo', 'yen', 'youtube', 'youtube-play', 'youtube-square', 'bluetooth', 'bluetooth-b', 'codiepie','credit-card-alt', 'edge', 'fort-awesome', 'hashtag', 'mixcloud', 'modx', 'pause-circle', 'pause-circle-o', 'percent', 'product-hunt', 'reddit-alien', 'scribd', 'shopping-bag', 'shopping-basket', 'stop-circle', 'stop-circle-o', 'usb' ) );
	}

	/**
	 * Animate.css animations
	 */
	public static function animations() {
		return apply_filters( 'ts/data/animations', array( 'flash', 'bounce', 'shake', 'tada', 'swing', 'wobble', 'pulse', 'flip', 'flipInX', 'flipOutX', 'flipInY', 'flipOutY', 'fadeIn', 'fadeInUp', 'fadeInDown', 'fadeInLeft', 'fadeInRight', 'fadeInUpBig', 'fadeInDownBig', 'fadeInLeftBig', 'fadeInRightBig', 'fadeOut', 'fadeOutUp', 'fadeOutDown', 'fadeOutLeft', 'fadeOutRight', 'fadeOutUpBig', 'fadeOutDownBig', 'fadeOutLeftBig', 'fadeOutRightBig', 'slideInDown', 'slideInLeft', 'slideInRight', 'slideOutUp', 'slideOutLeft', 'slideOutRight', 'bounceIn', 'bounceInDown', 'bounceInUp', 'bounceInLeft', 'bounceInRight', 'bounceOut', 'bounceOutDown', 'bounceOutUp', 'bounceOutLeft', 'bounceOutRight', 'rotateIn', 'rotateInDownLeft', 'rotateInDownRight', 'rotateInUpLeft', 'rotateInUpRight', 'rotateOut', 'rotateOutDownLeft', 'rotateOutDownRight', 'rotateOutUpLeft', 'rotateOutUpRight', 'lightSpeedIn', 'lightSpeedOut', 'hinge', 'rollIn', 'rollOut' ) );
	}

	/**
	 * Examples section
	 */
	public static function examples() {
		return apply_filters( 'ts/data/examples', array(
				'basic' => array(
					'title' => __( 'Basic examples', 'testo' ),
					'items' => array(
						array(
							'name' => __( 'Accordions, spoilers, different styles, anchors', 'testo' ),
							'id'   => 'spoilers',
							'code' => plugin_dir_path( TS_PLUGIN_FILE ) . '/inc/examples/spoilers.example',
							'icon' => 'tasks'
						),
						array(
							'name' => __( 'Tabs, vertical tabs, tab anchors', 'testo' ),
							'id'   => 'tabs',
							'code' => plugin_dir_path( TS_PLUGIN_FILE ) . '/inc/examples/tabs.example',
							'icon' => 'folder'
						),
						array(
							'name' => __( 'Column layouts', 'testo' ),
							'id'   => 'columns',
							'code' => plugin_dir_path( TS_PLUGIN_FILE ) . '/inc/examples/columns.example',
							'icon' => 'th-large'
						),
						array(
							'name' => __( 'Media elements, YouTube, Vimeo, Screenr and self-hosted videos, audio player', 'testo' ),
							'id'   => 'media',
							'code' => plugin_dir_path( TS_PLUGIN_FILE ) . '/inc/examples/media.example',
							'icon' => 'play-circle'
						),
						array(
							'name' => __( 'Unlimited buttons', 'testo' ),
							'id'   => 'buttons',
							'code' => plugin_dir_path( TS_PLUGIN_FILE ) . '/inc/examples/buttons.example',
							'icon' => 'heart'
						),
						array(
							'name' => __( 'Animations', 'testo' ),
							'id'   => 'animations',
							'code' => plugin_dir_path( TS_PLUGIN_FILE ) . '/inc/examples/animations.example',
							'icon' => 'bolt'
						),
					)
				),
				'advanced' => array(
					'title' => __( 'Advanced examples', 'testo' ),
					'items' => array(
						array(
							'name' => __( 'Interacting with posts shortcode', 'testo' ),
							'id' => 'posts',
							'code' => plugin_dir_path( TS_PLUGIN_FILE ) . '/inc/examples/posts.example',
							'icon' => 'list'
						),
						array(
							'name' => __( 'Nested shortcodes, shortcodes inside of attributes', 'testo' ),
							'id' => 'nested',
							'code' => plugin_dir_path( TS_PLUGIN_FILE ) . '/inc/examples/nested.example',
							'icon' => 'indent'
						),
					)
				),
			) );
	}

	/**
	 * Shortcodes
	 */
	public static function shortcodes( $shortcode = false ) {
		$shortcodes = apply_filters( 'ts/data/shortcodes', array(
				// heading
				'heading' => array(
					'name' => __( 'Heading', 'testo' ),
					'type' => 'wrap',
					'group' => 'content',
					'atts' => array(
						'tag' => array(
							'type' => 'select',
							'values' => array(
								'h1' => __( 'H1', 'testo' ),
								'h2' => __( 'H2', 'testo' ),
								'h3' => __( 'H3', 'testo' ),
								'h4' => __( 'H4', 'testo' ),
								'h5' => __( 'H5', 'testo' ),
								'h6' => __( 'H6', 'testo' ),
							),
							'default' => 'h2',
							'name' => __( 'Select Tag', 'testo' ),
							'desc' => __( 'Choose heading tag for this heading', 'testo' ) 
						),
						'size' => array(
							'type' => 'slider',
							'min' => 7,
							'max' => 90,
							'step' => 1,
							'default' => 48,
							'name' => __( 'Size', 'testo' ),
							'desc' => __( 'Select heading size (pixels)', 'testo' )
						),
						'color' => array(
							'type' => 'color',
							'default' => '#ffffff',
							'name' => __( 'Color', 'testo' ),
							'desc' => __( 'Select heading color', 'testo' )
						),
						'align' => array(
							'type' => 'select',
							'values' => array(
								'left' => __( 'Left', 'testo' ),
								'center' => __( 'Center', 'testo' ),
								'right' => __( 'Right', 'testo' )
							),
							'default' => 'center',
							'name' => __( 'Align', 'testo' ),
							'desc' => __( 'Heading text alignment', 'testo' )
						),
						'margin_top' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 200,
							'step' => 5,
							'default' => 20,
							'name' => __( 'Margin Top', 'testo' ),
							'desc' => __( 'Top margin (pixels)', 'testo' )
						),
						'margin_bottom' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 200,
							'step' => 5,
							'default' => 20,
							'name' => __( 'Margin Bottom', 'testo' ),
							'desc' => __( 'Bottom margin (pixels)', 'testo' )
						),
						'text_transform' => array(
							'type' => 'select',
							'values' => array(
								'uppercase' => __( 'Uppercase', 'testo' ),
								'lowercase' => __( 'Lowercase', 'testo' ),
								'capitalize' => __( 'Capitalize', 'testo' ),
							),
							'default' => 'uppercase',
							'name' => __( 'Text Tranform', 'testo' ),
							'desc' => __( 'Choose a text transform style', 'testo' )
						),
						'letter_spacing' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 40,
							'step' => 1,
							'default' => 28,
							'name' => __( 'Letter Spacing', 'testo' ),
							'desc' => __( 'Letter Spacing (pixels)', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Heading text', 'testo' ),
					'desc' => __( 'Styled heading', 'testo' ),
					'icon' => 'h-square'
				),
				// tabs
				'tabs' => array(
					'name' => __( 'Tabs', 'testo' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'testo' ),
								'style_2' => __( 'Style 2', 'testo' )
							),
							'default' => 'default',
							'name' => __( 'Style', 'testo' ),
							'desc' => __( 'Choose style for this tabs', 'testo' ) . '%ts_skins_link%'
						),
						'active' => array(
							'type' => 'number',
							'min' => 1,
							'max' => 100,
							'step' => 1,
							'default' => 1,
							'name' => __( 'Active tab', 'testo' ),
							'desc' => __( 'Select which tab is open by default', 'testo' )
						),
						'vertical' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Vertical', 'testo' ),
							'desc' => __( 'Show tabs vertically', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( "[%prefix_tab title=\"Title 1\"]Content 1[/%prefix_tab]\n[%prefix_tab title=\"Title 2\"]Content 2[/%prefix_tab]\n[%prefix_tab title=\"Title 3\"]Content 3[/%prefix_tab]", 'testo' ),
					'desc' => __( 'Tabs container', 'testo' ),
					'example' => 'tabs',
					'icon' => 'list-alt'
				),
				// tab
				'tab' => array(
					'name' => __( 'Tab', 'testo' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'title' => array(
							'default' => __( 'Tab name', 'testo' ),
							'name' => __( 'Title', 'testo' ),
							'desc' => __( 'Enter tab name', 'testo' )
						),
						'disabled' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Disabled', 'testo' ),
							'desc' => __( 'Is this tab disabled', 'testo' )
						),
						'anchor' => array(
							'default' => '',
							'name' => __( 'Anchor', 'testo' ),
							'desc' => __( 'You can use unique anchor for this tab to access it with hash in page url. For example: type here <b%value>Hello</b> and then use url like http://example.com/page-url#Hello. This tab will be activated and scrolled in', 'testo' )
						),
						'url' => array(
							'default' => '',
							'name' => __( 'URL', 'testo' ),
							'desc' => __( 'You can link this tab to any webpage. Enter here full URL to switch this tab into link', 'testo' )
						),
						'target' => array(
							'type' => 'select',
							'values' => array(
								'self'  => __( 'Open link in same window/tab', 'testo' ),
								'blank' => __( 'Open link in new window/tab', 'testo' )
							),
							'default' => 'blank',
							'name' => __( 'Link target', 'testo' ),
							'desc' => __( 'Choose how to open the custom tab link', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Tab content', 'testo' ),
					'desc' => __( 'Single tab', 'testo' ),
					'note' => __( 'Did you know that you need to wrap single tabs with [tabs] shortcode?', 'testo' ),
					'example' => 'tabs',
					'icon' => 'list-alt'
				),
				// spoiler
				'spoiler' => array(
					'name' => __( 'Spoiler', 'testo' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'title' => array(
							'default' => __( 'Spoiler title', 'testo' ),
							'name' => __( 'Title', 'testo' ), 'desc' => __( 'Text in spoiler title', 'testo' )
						),
						'open' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Open', 'testo' ),
							'desc' => __( 'Is spoiler content visible by default', 'testo' )
						),
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'testo' ),
								'fancy' => __( 'Fancy', 'testo' ),
								'simple' => __( 'Simple', 'testo' )
							),
							'default' => 'default',
							'name' => __( 'Style', 'testo' ),
							'desc' => __( 'Choose style for this spoiler', 'testo' ) . '%ts_skins_link%'
						),
						'icon' => array(
							'type' => 'select',
							'values' => array(
								'plus'           => __( 'Plus', 'testo' ),
								'plus-circle'    => __( 'Plus circle', 'testo' ),
								'plus-square-1'  => __( 'Plus square 1', 'testo' ),
								'plus-square-2'  => __( 'Plus square 2', 'testo' ),
								'arrow'          => __( 'Arrow', 'testo' ),
								'arrow-circle-1' => __( 'Arrow circle 1', 'testo' ),
								'arrow-circle-2' => __( 'Arrow circle 2', 'testo' ),
								'chevron'        => __( 'Chevron', 'testo' ),
								'chevron-circle' => __( 'Chevron circle', 'testo' ),
								'caret'          => __( 'Caret', 'testo' ),
								'caret-square'   => __( 'Caret square', 'testo' ),
								'folder-1'       => __( 'Folder 1', 'testo' ),
								'folder-2'       => __( 'Folder 2', 'testo' )
							),
							'default' => 'plus',
							'name' => __( 'Icon', 'testo' ),
							'desc' => __( 'Icons for spoiler', 'testo' )
						),
						'anchor' => array(
							'default' => '',
							'name' => __( 'Anchor', 'testo' ),
							'desc' => __( 'You can use unique anchor for this spoiler to access it with hash in page url. For example: type here <b%value>Hello</b> and then use url like http://example.com/page-url#Hello. This spoiler will be open and scrolled in', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Hidden content', 'testo' ),
					'desc' => __( 'Spoiler with hidden content', 'testo' ),
					'note' => __( 'Did you know that you can wrap multiple spoilers with [accordion] shortcode to create accordion effect?', 'testo' ),
					'example' => 'spoilers',
					'icon' => 'list-ul'
				),
				// accordion
				'accordion' => array(
					'name' => __( 'Accordion', 'testo' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( "[%prefix_spoiler]Content[/%prefix_spoiler]\n[%prefix_spoiler]Content[/%prefix_spoiler]\n[%prefix_spoiler]Content[/%prefix_spoiler]", 'testo' ),
					'desc' => __( 'Accordion with spoilers', 'testo' ),
					'note' => __( 'Did you know that you can wrap multiple spoilers with [accordion] shortcode to create accordion effect?', 'testo' ),
					'example' => 'spoilers',
					'icon' => 'list'
				),
				// divider
				'divider' => array(
					'name' => __( 'Divider', 'testo' ),
					'type' => 'single',
					'group' => 'content',
					'atts' => array(
						'top' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show TOP link', 'testo' ),
							'desc' => __( 'Show link to top of the page or not', 'testo' )
						),
						'text' => array(
							'values' => array( ),
							'default' => __( 'Go to top', 'testo' ),
							'name' => __( 'Link text', 'testo' ), 'desc' => __( 'Text for the GO TOP link', 'testo' )
						),
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'testo' ),
								'dotted'  => __( 'Dotted', 'testo' ),
								'dashed'  => __( 'Dashed', 'testo' ),
								'double'  => __( 'Double', 'testo' )
							),
							'default' => 'default',
							'name' => __( 'Style', 'testo' ),
							'desc' => __( 'Choose style for this divider', 'testo' )
						),
						'divider_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#999999',
							'name' => __( 'Divider color', 'testo' ),
							'desc' => __( 'Pick the color for divider', 'testo' )
						),
						'link_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#999999',
							'name' => __( 'Link color', 'testo' ),
							'desc' => __( 'Pick the color for TOP link', 'testo' )
						),
						'size' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 40,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Size', 'testo' ),
							'desc' => __( 'Height of the divider (in pixels)', 'testo' )
						),
						'margin' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 200,
							'step' => 5,
							'default' => 15,
							'name' => __( 'Margin', 'testo' ),
							'desc' => __( 'Adjust the top and bottom margins of this divider (in pixels)', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'desc' => __( 'Content divider with optional TOP link', 'testo' ),
					'icon' => 'ellipsis-h'
				),
				// spacer
				'spacer' => array(
					'name' => __( 'Spacer', 'testo' ),
					'type' => 'single',
					'group' => 'content other',
					'atts' => array(
						'size' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 800,
							'step' => 10,
							'default' => 20,
							'name' => __( 'Height', 'testo' ),
							'desc' => __( 'Height of the spacer in pixels', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'desc' => __( 'Empty space with adjustable height', 'testo' ),
					'icon' => 'arrows-v'
				),
				// highlight
				'highlight' => array(
					'name' => __( 'Highlight', 'testo' ),
					'type' => 'wrap',
					'group' => 'content',
					'atts' => array(
						'background' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#DDFF99',
							'name' => __( 'Background', 'testo' ),
							'desc' => __( 'Highlighted text background color', 'testo' )
						),
						'color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#000000',
							'name' => __( 'Text color', 'testo' ), 'desc' => __( 'Highlighted text color', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Highlighted text', 'testo' ),
					'desc' => __( 'Highlighted text', 'testo' ),
					'icon' => 'pencil'
				),
				// color_overlay
				'color_overlay' => array(
					'name' => __( 'Background Overlay', 'testo' ),
					'type' => 'single',
					'group' => 'testo',
					'atts' => array(
						'background' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#000000',
							'name' => __( 'Background', 'testo' ),
							'desc' => __( 'Overlay background color', 'testo' )
						),
						'opacity' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 1,
							'step' => 0.1,
							'default' => 0.5,
							'name' => __( 'Opacity', 'testo' ),
							'desc' => __( 'Choose opacity', 'testo' )
						),
						'display_style' => array(
							'type' => 'select',
							'values' => array(
								'normal' => __( 'normal', 'testo' ),
								'hover' => __( 'only hover', 'testo' ),
							),
							'default' => 'default',
							'name' => __( 'Type', 'testo' ),
							'desc' => __( 'Style of the label', 'testo' )
						),
					),
					'content' => __( '', 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'pencil'
				),
				
				// label
				'label' => array(
					'name' => __( 'Label', 'testo' ),
					'type' => 'wrap',
					'group' => 'content',
					'atts' => array(
						'type' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'testo' ),
								'success' => __( 'Success', 'testo' ),
								'warning' => __( 'Warning', 'testo' ),
								'important' => __( 'Important', 'testo' ),
								'black' => __( 'Black', 'testo' ),
								'info' => __( 'Info', 'testo' )
							),
							'default' => 'default',
							'name' => __( 'Type', 'testo' ),
							'desc' => __( 'Style of the label', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Label', 'testo' ),
					'desc' => __( 'Styled label', 'testo' ),
					'icon' => 'tag'
				),
				// quote
				'quote' => array(
					'name' => __( 'Quote', 'testo' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'testo' )
							),
							'default' => 'default',
							'name' => __( 'Style', 'testo' ),
							'desc' => __( 'Choose style for this quote', 'testo' ) . '%ts_skins_link%'
						),
						'cite' => array(
							'default' => '',
							'name' => __( 'Cite', 'testo' ),
							'desc' => __( 'Quote author name', 'testo' )
						),
						'url' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Cite url', 'testo' ),
							'desc' => __( 'Url of the quote author. Leave empty to disable link', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Quote', 'testo' ),
					'desc' => __( 'Blockquote alternative', 'testo' ),
					'icon' => 'quote-right'
				),
				// pullquote
				'pullquote' => array(
					'name' => __( 'Pullquote', 'testo' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'align' => array(
							'type' => 'select',
							'values' => array(
								'left' => __( 'Left', 'testo' ),
								'right' => __( 'Right', 'testo' )
							),
							'default' => 'left',
							'name' => __( 'Align', 'testo' ), 'desc' => __( 'Pullquote alignment (float)', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Pullquote', 'testo' ),
					'desc' => __( 'Pullquote', 'testo' ),
					'icon' => 'quote-left'
				),
				// dropcap
				'dropcap' => array(
					'name' => __( 'Dropcap', 'testo' ),
					'type' => 'wrap',
					'group' => 'content',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'testo' ),
								'flat' => __( 'Flat', 'testo' ),
								'light' => __( 'Light', 'testo' ),
								'simple' => __( 'Simple', 'testo' )
							),
							'default' => 'default',
							'name' => __( 'Style', 'testo' ), 'desc' => __( 'Dropcap style preset', 'testo' )
						),
						'size' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 5,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Size', 'testo' ),
							'desc' => __( 'Choose dropcap size', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'D', 'testo' ),
					'desc' => __( 'Dropcap', 'testo' ),
					'icon' => 'bold'
				),
				// frame
				'frame' => array(
					'name' => __( 'Frame', 'testo' ),
					'type' => 'wrap',
					'group' => 'content',
					'atts' => array(
						'align' => array(
							'type' => 'select',
							'values' => array(
								'left' => __( 'Left', 'testo' ),
								'center' => __( 'Center', 'testo' ),
								'right' => __( 'Right', 'testo' )
							),
							'default' => 'left',
							'name' => __( 'Align', 'testo' ),
							'desc' => __( 'Frame alignment', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => '<img src="http://lorempixel.com/g/400/200/" />',
					'desc' => __( 'Styled image frame', 'testo' ),
					'icon' => 'picture-o'
				),
				// row
				'row' => array(
					'name' => __( 'Row', 'testo' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( "[%prefix_column size=\"1/3\"]Content[/%prefix_column]\n[%prefix_column size=\"1/3\"]Content[/%prefix_column]\n[%prefix_column size=\"1/3\"]Content[/%prefix_column]", 'testo' ),
					'desc' => __( 'Row for flexible columns', 'testo' ),
					'icon' => 'columns'
				),
				// column
				'column' => array(
					'name' => __( 'Column', 'testo' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'size' => array(
							'type' => 'select',
							'values' => array(
								'1/1' => __( 'Full width', 'testo' ),
								'1/2' => __( 'One half', 'testo' ),
								'1/3' => __( 'One third', 'testo' ),
								'2/3' => __( 'Two third', 'testo' ),
								'1/4' => __( 'One fourth', 'testo' ),
								'3/4' => __( 'Three fourth', 'testo' ),
								'1/5' => __( 'One fifth', 'testo' ),
								'2/5' => __( 'Two fifth', 'testo' ),
								'3/5' => __( 'Three fifth', 'testo' ),
								'4/5' => __( 'Four fifth', 'testo' ),
								'1/6' => __( 'One sixth', 'testo' ),
								'5/6' => __( 'Five sixth', 'testo' )
							),
							'default' => '1/2',
							'name' => __( 'Size', 'testo' ),
							'desc' => __( 'Select column width. This width will be calculated depend page width', 'testo' )
						),
						'center' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Centered', 'testo' ),
							'desc' => __( 'Is this column centered on the page', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Column content', 'testo' ),
					'desc' => __( 'Flexible and responsive columns', 'testo' ),
					'note' => __( 'Did you know that you need to wrap columns with [row] shortcode?', 'testo' ),
					'example' => 'columns',
					'icon' => 'columns'
				),
				// list
				'list' => array(
					'name' => __( 'List', 'testo' ),
					'type' => 'wrap',
					'group' => 'content',
					'atts' => array(
						'icon' => array(
							'type' => 'icon',
							'default' => '',
							'name' => __( 'Icon', 'testo' ),
							'desc' => __( 'select icon from here, You can upload custom icon for this box', 'testo' )
						),
						'icon_color' => array(
							'type' => 'color',
							'default' => '#333333',
							'name' => __( 'Icon color', 'testo' ),
							'desc' => __( 'This color will be applied to the selected icon. Does not works with uploaded icons', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( "<ul>\n<li>List item</li>\n<li>List item</li>\n<li>List item</li>\n</ul>", 'testo' ),
					'desc' => __( 'Styled unordered list', 'testo' ),
					'icon' => 'list-ol'
				),
				// button
				'button' => array(
					'name' => __( 'Button', 'testo' ),
					'type' => 'wrap',
					'group' => 'content',
					'atts' => array(
						'url' => array(
							'values' => array( ),
							'default' => get_option( 'home' ),
							'name' => __( 'Link', 'testo' ),
							'desc' => __( 'Button link', 'testo' )
						),
						'target' => array(
							'type' => 'select',
							'values' => array(
								'self' => __( 'Same tab', 'testo' ),
								'blank' => __( 'New tab', 'testo' )
							),
							'default' => 'self',
							'name' => __( 'Target', 'testo' ),
							'desc' => __( 'Button link target', 'testo' )
						),
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'testo' ),
								'standard' => __( 'Standard', 'testo' ),
								'flat' => __( 'Flat', 'testo' ),
								'ghost' => __( 'Ghost', 'testo' ),
								'soft' => __( 'Soft', 'testo' ),
								'glass' => __( 'Glass', 'testo' ),
								'bubbles' => __( 'Bubbles', 'testo' ),
								'noise' => __( 'Noise', 'testo' ),
								'stroked' => __( 'Stroked', 'testo' ),
								'3d' => __( '3D', 'testo' )
							),
							'default' => 'default',
							'name' => __( 'Style', 'testo' ), 
							'desc' => __( 'Button background style preset', 'testo' )
						),
						'background' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#FFFFFF',
							'name' => __( 'Background', 'testo' ), 
							'desc' => __( 'Button background color', 'testo' )
						),
						'opacity' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 1,
							'step' => 0.1,
							'default' => 0,
							'name' => __( 'Opacity', 'testo' ),
							'desc' => __( 'Background Opacity', 'testo' )
						),
						'background_hover' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#f3b723',
							'name' => __( 'Background Hover', 'testo' ), 
							'desc' => __( 'Button background hover color', 'testo' )
						),
						'border' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#121212',
							'name' => __( 'Border Color', 'testo' ), 
							'desc' => __( 'Border color', 'testo' )
						),
						'border_hover' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#121212',
							'name' => __( 'Border Hover Color', 'testo' ), 
							'desc' => __( 'Border hover color', 'testo' )
						),
						'color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#ffffff',
							'name' => __( 'Text color', 'testo' ),
							'desc' => __( 'Button text color', 'testo' )
						),
						'color_hover' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#ffffff',
							'name' => __( 'Text color hover', 'testo' ),
							'desc' => __( 'Button text color on hover', 'testo' )
						),
						'line_height' => array(
							'type' => 'slider',
							'min' => 18,
							'max' => 100,
							'step' => 1,
							'default' => 18,
							'name' => __( 'Line Height', 'testo' ),
							'desc' => __( 'Line Height of Button text', 'testo' )
						),
						'size' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 20,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Size', 'testo' ),
							'desc' => __( 'Button size', 'testo' )
						),
						'wide' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Fluid', 'testo' ), 
							'desc' => __( 'Fluid buttons has 100% width', 'testo' )
						),
						'center' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Centered', 'testo' ), 
							'desc' => __( 'Is button centered on the page', 'testo' )
						),
						'radius' => array(
							'type' => 'select',
							'values' => array(
								'auto' => __( 'Auto', 'testo' ),
								'round' => __( 'Round', 'testo' ),
								'0' => __( 'Square', 'testo' ),
								'5' => '5px',
								'10' => '10px',
								'20' => '20px',
								'30' => '30px'
							),
							'default' => 'auto',
							'name' => __( 'Radius', 'testo' ),
							'desc' => __( 'Radius of button corners. Auto-radius calculation based on button size', 'testo' )
						),
						'icon' => array(
							'type' => 'icon',
							'default' => '',
							'name' => __( 'Icon', 'testo' ),
							'desc' => __( 'You can upload custom icon for this box', 'testo' )
						),
						'icon_color' => array(
							'type' => 'color',
							'default' => '#121212',
							'name' => __( 'Icon color', 'testo' ),
							'desc' => __( 'This color will be applied to the selected icon. Does not works with uploaded icons', 'testo' )
						),
						'text_shadow' => array(
							'type' => 'shadow',
							'default' => 'none',
							'name' => __( 'Text shadow', 'testo' ),
							'desc' => __( 'Button text shadow', 'testo' )
						),
						'desc' => array(
							'default' => '',
							'name' => __( 'Description', 'testo' ),
							'desc' => __( 'Small description under button text. This option is incompatible with icon.', 'testo' )
						),
						'onclick' => array(
							'default' => '',
							'name' => __( 'onClick', 'testo' ),
							'desc' => __( 'Advanced JavaScript code for onClick action', 'testo' )
						),
						'rel' => array(
							'default' => '',
							'name' => __( 'Rel attribute', 'testo' ),
							'desc' => __( 'Here you can add value for the rel attribute.<br>Example values: <b%value>nofollow</b>, <b%value>lightbox</b>', 'testo' )
						),
						'title' => array(
							'default' => '',
							'name' => __( 'Title attribute', 'testo' ),
							'desc' => __( 'Here you can add value for the title attribute', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Button text', 'testo' ),
					'desc' => __( 'Styled button', 'testo' ),
					'example' => 'buttons',
					'icon' => 'heart'
				),
				
				//services
			    'services' => 
				array(
					'name' => __( 'Services', 'testo' ),
					'type' => 'wrap',
					'group' => 'testo',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'testo' ),
								'style_2' => __( 'Services Style 2', 'testo' ),
							),
							'default' => 'style_2',
							'name' => __( 'Style', 'testo' ),
							'desc' => __( 'Box style preset', 'testo' )
						),					
						),
					'content' => __( 'Single service shortcode goes here', 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'check-square-o'
				),
				// service
				'service' => array(
					'name' => __( 'Service', 'testo' ),
					'type' => 'wrap',
					'group' => 'testo',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'testo' ),
								'style_2' => __( 'Style 2', 'testo' ),
							),
							'default' => 'default',
							'name' => __( 'Style', 'testo' ),
							'desc' => __( 'Style of service', 'testo' )
						),
						'title' => array(
							'values' => array( ),
							'default' => __( 'Service title', 'testo' ),
							'name' => __( 'Title', 'testo' ),
							'desc' => __( 'Service name', 'testo' )
						),
						'flat_icon' => array(
							'type' => 'text',
							'default' => '',
							'name' => __( 'Flat Icon', 'testo' ),
							'desc' => __( 'Write your flat icon class here; example: shopping-basket', 'testo' )
						),
						'icon' => array(
							'type' => 'icon',
							'default' => '',
							'name' => __( 'Icon', 'testo' ),
							'desc' => __( 'select icon from here, You can upload custom icon for this box', 'testo' )
						),
						'icon_color' => array(
							'type' => 'color',
							'default' => '#333333',
							'name' => __( 'Icon color', 'testo' ),
							'desc' => __( 'This color will be applied to the selected icon. Does not works with uploaded icons', 'testo' )
						),
						'size' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 128,
							'step' => 2,
							'default' => 32,
							'name' => __( 'Icon size', 'testo' ),
							'desc' => __( 'Size of the uploaded icon in pixels', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Service description', 'testo' ),
					'desc' => __( 'Service box with title', 'testo' ),
					'icon' => 'check-square-o'
				),
				
				// box
				'box' => array(
					'name' => __( 'Box', 'testo' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'title' => array(
							'values' => array( ),
							'default' => __( 'Box title', 'testo' ),
							'name' => __( 'Title', 'testo' ), 'desc' => __( 'Text for the box title', 'testo' )
						),
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'testo' ),
								'soft' => __( 'Soft', 'testo' ),
								'glass' => __( 'Glass', 'testo' ),
								'bubbles' => __( 'Bubbles', 'testo' ),
								'noise' => __( 'Noise', 'testo' )
							),
							'default' => 'default',
							'name' => __( 'Style', 'testo' ),
							'desc' => __( 'Box style preset', 'testo' )
						),
						'box_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#333333',
							'name' => __( 'Color', 'testo' ),
							'desc' => __( 'Color for the box title and borders', 'testo' )
						),
						'title_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#FFFFFF',
							'name' => __( 'Title text color', 'testo' ), 'desc' => __( 'Color for the box title text', 'testo' )
						),
						'radius' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 20,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Radius', 'testo' ),
							'desc' => __( 'Box corners radius', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Box content', 'testo' ),
					'desc' => __( 'Colored box with caption', 'testo' ),
					'icon' => 'list-alt'
				),
				// note
				'note' => array(
					'name' => __( 'Note', 'testo' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'note_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#FFFF66',
							'name' => __( 'Background', 'testo' ), 'desc' => __( 'Note background color', 'testo' )
						),
						'text_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#333333',
							'name' => __( 'Text color', 'testo' ),
							'desc' => __( 'Note text color', 'testo' )
						),
						'radius' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 20,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Radius', 'testo' ), 'desc' => __( 'Note corners radius', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Note text', 'testo' ),
					'desc' => __( 'Colored box', 'testo' ),
					'icon' => 'list-alt'
				),
				// expand
				'expand' => array(
					'name' => __( 'Expand', 'testo' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'more_text' => array(
							'default' => __( 'Show more', 'testo' ),
							'name' => __( 'More text', 'testo' ),
							'desc' => __( 'Enter the text for more link', 'testo' )
						),
						'less_text' => array(
							'default' => __( 'Show less', 'testo' ),
							'name' => __( 'Less text', 'testo' ),
							'desc' => __( 'Enter the text for less link', 'testo' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 1000,
							'step' => 10,
							'default' => 100,
							'name' => __( 'Height', 'testo' ),
							'desc' => __( 'Height for collapsed state (in pixels)', 'testo' )
						),
						'hide_less' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Hide less link', 'testo' ),
							'desc' => __( 'This option allows you to hide less link, when the text block has been expanded', 'testo' )
						),
						'text_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#333333',
							'name' => __( 'Text color', 'testo' ),
							'desc' => __( 'Pick the text color', 'testo' )
						),
						'link_color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#0088FF',
							'name' => __( 'Link color', 'testo' ),
							'desc' => __( 'Pick the link color', 'testo' )
						),
						'link_style' => array(
							'type' => 'select',
							'values' => array(
								'default'    => __( 'Default', 'testo' ),
								'underlined' => __( 'Underlined', 'testo' ),
								'dotted'     => __( 'Dotted', 'testo' ),
								'dashed'     => __( 'Dashed', 'testo' ),
								'button'     => __( 'Button', 'testo' ),
							),
							'default' => 'default',
							'name' => __( 'Link style', 'testo' ),
							'desc' => __( 'Select the style for more/less link', 'testo' )
						),
						'link_align' => array(
							'type' => 'select',
							'values' => array(
								'left' => __( 'Left', 'testo' ),
								'center' => __( 'Center', 'testo' ),
								'right' => __( 'Right', 'testo' ),
							),
							'default' => 'left',
							'name' => __( 'Link align', 'testo' ),
							'desc' => __( 'Select link alignment', 'testo' )
						),
						'more_icon' => array(
							'type' => 'icon',
							'default' => '',
							'name' => __( 'More icon', 'testo' ),
							'desc' => __( 'Add an icon to the more link', 'testo' )
						),
						'less_icon' => array(
							'type' => 'icon',
							'default' => '',
							'name' => __( 'Less icon', 'testo' ),
							'desc' => __( 'Add an icon to the less link', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'This text block can be expanded', 'testo' ),
					'desc' => __( 'Expandable text block', 'testo' ),
					'icon' => 'sort-amount-asc'
				),
				// lightbox
				'lightbox' => array(
					'name' => __( 'Lightbox', 'testo' ),
					'type' => 'wrap',
					'group' => 'gallery',
					'atts' => array(
						'type' => array(
							'type' => 'select',
							'values' => array(
								'iframe' => __( 'Iframe', 'testo' ),
								'image' => __( 'Image', 'testo' ),
								'inline' => __( 'Inline (html content)', 'testo' )
							),
							'default' => 'iframe',
							'name' => __( 'Content type', 'testo' ),
							'desc' => __( 'Select type of the lightbox window content', 'testo' )
						),
						'src' => array(
							'default' => '',
							'name' => __( 'Content source', 'testo' ),
							'desc' => __( 'Insert here URL or CSS selector. Use URL for Iframe and Image content types. Use CSS selector for Inline content type.<br />Example values:<br /><b%value>http://www.youtube.com/watch?v=XXXXXXXXX</b> - YouTube video (iframe)<br /><b%value>http://example.com/wp-content/uploads/image.jpg</b> - uploaded image (image)<br /><b%value>http://example.com/</b> - any web page (iframe)<br /><b%value>#my-custom-popup</b> - any HTML content (inline)', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( '[%prefix_button] Click Here to Watch the Video [/%prefix_button]', 'testo' ),
					'desc' => __( 'Lightbox window with custom content', 'testo' ),
					'icon' => 'external-link'
				),
				// lightbox content
				'lightbox_content' => array(
					'name' => __( 'Lightbox content', 'testo' ),
					'type' => 'wrap',
					'group' => 'gallery',
					'atts' => array(
						'id' => array(
							'default' => '',
							'name' => __( 'ID', 'testo' ),
							'desc' => sprintf( __( 'Enter here the ID from Content source field. %s Example value: %s', 'testo' ), '<br>', '<b%value>my-custom-popup</b>' )
						),
						'width' => array(
							'default' => '50%',
							'name' => __( 'Width', 'testo' ),
							'desc' => sprintf( __( 'Adjust the width for inline content (in pixels or percents). %s Example values: %s, %s, %s', 'testo' ), '<br>', '<b%value>300px</b>', '<b%value>600px</b>', '<b%value>90%</b>' )
						),
						'margin' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 600,
							'step' => 5,
							'default' => 40,
							'name' => __( 'Margin', 'testo' ),
							'desc' => __( 'Adjust the margin for inline content (in pixels)', 'testo' )
						),
						'padding' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 600,
							'step' => 5,
							'default' => 40,
							'name' => __( 'Padding', 'testo' ),
							'desc' => __( 'Adjust the padding for inline content (in pixels)', 'testo' )
						),
						'text_align' => array(
							'type' => 'select',
							'values' => array(
								'center' => __( 'Center', 'testo' ),
								'left' => __( 'Left', 'testo' ),
								'right' => __( 'Right', 'testo' ),
								'justify' => __( 'Justify', 'testo' ),
							),
							'default' => 'center',
							'name' => __( 'Text Align', 'testo' ),
							'desc' => __( 'Choose text align', 'testo' )
						),
						'background' => array(
							'type' => 'color',
							'default' => '#FFFFFF',
							'name' => __( 'Background color', 'testo' ),
							'desc' => __( 'Pick a background color', 'testo' )
						),
						'color' => array(
							'type' => 'color',
							'default' => '#333333',
							'name' => __( 'Text color', 'testo' ),
							'desc' => __( 'Pick a text color', 'testo' )
						),
						'color' => array(
							'type' => 'color',
							'default' => '#333333',
							'name' => __( 'Text color', 'testo' ),
							'desc' => __( 'Pick a text color', 'testo' )
						),
						'shadow' => array(
							'type' => 'shadow',
							'default' => '0px 0px 15px #333333',
							'name' => __( 'Shadow', 'testo' ),
							'desc' => __( 'Adjust the shadow for content box', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Inline content', 'testo' ),
					'desc' => __( 'Inline content for lightbox', 'testo' ),
					'icon' => 'external-link'
				),
				// tooltip
				'tooltip' => array(
					'name' => __( 'Tooltip', 'testo' ),
					'type' => 'wrap',
					'group' => 'other',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'light' => __( 'Basic: Light', 'testo' ),
								'dark' => __( 'Basic: Dark', 'testo' ),
								'yellow' => __( 'Basic: Yellow', 'testo' ),
								'green' => __( 'Basic: Green', 'testo' ),
								'red' => __( 'Basic: Red', 'testo' ),
								'blue' => __( 'Basic: Blue', 'testo' ),
								'youtube' => __( 'Youtube', 'testo' ),
								'tipsy' => __( 'Tipsy', 'testo' ),
								'bootstrap' => __( 'Bootstrap', 'testo' ),
								'jtools' => __( 'jTools', 'testo' ),
								'tipped' => __( 'Tipped', 'testo' ),
								'cluetip' => __( 'Cluetip', 'testo' ),
							),
							'default' => 'yellow',
							'name' => __( 'Style', 'testo' ),
							'desc' => __( 'Tooltip window style', 'testo' )
						),
						'position' => array(
							'type' => 'select',
							'values' => array(
								'north' => __( 'Top', 'testo' ),
								'south' => __( 'Bottom', 'testo' ),
								'west' => __( 'Left', 'testo' ),
								'east' => __( 'Right', 'testo' )
							),
							'default' => 'top',
							'name' => __( 'Position', 'testo' ),
							'desc' => __( 'Tooltip position', 'testo' )
						),
						'shadow' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Shadow', 'testo' ),
							'desc' => __( 'Add shadow to tooltip. This option is only works with basic styes, e.g. blue, green etc.', 'testo' )
						),
						'rounded' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Rounded corners', 'testo' ),
							'desc' => __( 'Use rounded for tooltip. This option is only works with basic styes, e.g. blue, green etc.', 'testo' )
						),
						'size' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'testo' ),
								'1' => 1,
								'2' => 2,
								'3' => 3,
								'4' => 4,
								'5' => 5,
								'6' => 6,
							),
							'default' => 'default',
							'name' => __( 'Font size', 'testo' ),
							'desc' => __( 'Tooltip font size', 'testo' )
						),
						'title' => array(
							'default' => '',
							'name' => __( 'Tooltip title', 'testo' ),
							'desc' => __( 'Enter title for tooltip window. Leave this field empty to hide the title', 'testo' )
						),
						'content' => array(
							'default' => __( 'Tooltip text', 'testo' ),
							'name' => __( 'Tooltip content', 'testo' ),
							'desc' => __( 'Enter tooltip content here', 'testo' )
						),
						'behavior' => array(
							'type' => 'select',
							'values' => array(
								'hover' => __( 'Show and hide on mouse hover', 'testo' ),
								'click' => __( 'Show and hide by mouse click', 'testo' ),
								'always' => __( 'Always visible', 'testo' )
							),
							'default' => 'hover',
							'name' => __( 'Behavior', 'testo' ),
							'desc' => __( 'Select tooltip behavior', 'testo' )
						),
						'close' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Close button', 'testo' ),
							'desc' => __( 'Show close button', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( '[%prefix_button] Hover me to open tooltip [/%prefix_button]', 'testo' ),
					'desc' => __( 'Tooltip window with custom content', 'testo' ),
					'icon' => 'comment-o'
				),
				// private
				'private' => array(
					'name' => __( 'Private', 'testo' ),
					'type' => 'wrap',
					'group' => 'other',
					'atts' => array(
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Private note text', 'testo' ),
					'desc' => __( 'Private note for post authors', 'testo' ),
					'icon' => 'lock'
				),
				// youtube
				'youtube' => array(
					'name' => __( 'YouTube', 'testo' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Url', 'testo' ),
							'desc' => __( 'Url of YouTube page with video. Ex: http://youtube.com/watch?v=XXXXXX', 'testo' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'testo' ),
							'desc' => __( 'Player width', 'testo' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 400,
							'name' => __( 'Height', 'testo' ),
							'desc' => __( 'Player height', 'testo' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'testo' ),
							'desc' => __( 'Ignore width and height parameters and make player responsive', 'testo' )
						),
						'autoplay' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Autoplay', 'testo' ),
							'desc' => __( 'Play video automatically when page is loaded', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'desc' => __( 'YouTube video', 'testo' ),
					'example' => 'media',
					'icon' => 'youtube-play'
				),
				// youtube_advanced
				'youtube_advanced' => array(
					'name' => __( 'YouTube Advanced', 'testo' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Url', 'testo' ),
							'desc' => __( 'Url of YouTube page with video. Ex: http://youtube.com/watch?v=XXXXXX', 'testo' )
						),
						'playlist' => array(
							'default' => '',
							'name' => __( 'Playlist', 'testo' ),
							'desc' => __( 'Value is a comma-separated list of video IDs to play. If you specify a value, the first video that plays will be the VIDEO_ID specified in the URL path, and the videos specified in the playlist parameter will play thereafter', 'testo' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'testo' ),
							'desc' => __( 'Player width', 'testo' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 400,
							'name' => __( 'Height', 'testo' ),
							'desc' => __( 'Player height', 'testo' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'testo' ),
							'desc' => __( 'Ignore width and height parameters and make player responsive', 'testo' )
						),
						'controls' => array(
							'type' => 'select',
							'values' => array(
								'no' => __( '0 - Hide controls', 'testo' ),
								'yes' => __( '1 - Show controls', 'testo' ),
								'alt' => __( '2 - Show controls when playback is started', 'testo' )
							),
							'default' => 'yes',
							'name' => __( 'Controls', 'testo' ),
							'desc' => __( 'This parameter indicates whether the video player controls will display', 'testo' )
						),
						'autohide' => array(
							'type' => 'select',
							'values' => array(
								'no' => __( '0 - Do not hide controls', 'testo' ),
								'yes' => __( '1 - Hide all controls on mouse out', 'testo' ),
								'alt' => __( '2 - Hide progress bar on mouse out', 'testo' )
							),
							'default' => 'alt',
							'name' => __( 'Autohide', 'testo' ),
							'desc' => __( 'This parameter indicates whether the video controls will automatically hide after a video begins playing', 'testo' )
						),
						'showinfo' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show title bar', 'testo' ),
							'desc' => __( 'If you set the parameter value to NO, then the player will not display information like the video title and uploader before the video starts playing.', 'testo' )
						),
						'autoplay' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Autoplay', 'testo' ),
							'desc' => __( 'Play video automatically when page is loaded', 'testo' )
						),
						'loop' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Loop', 'testo' ),
							'desc' => __( 'Setting of YES will cause the player to play the initial video again and again', 'testo' )
						),
						'rel' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Related videos', 'testo' ),
							'desc' => __( 'This parameter indicates whether the player should show related videos when playback of the initial video ends', 'testo' )
						),
						'fs' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show full-screen button', 'testo' ),
							'desc' => __( 'Setting this parameter to NO prevents the fullscreen button from displaying', 'testo' )
						),
						'modestbranding' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => 'modestbranding',
							'desc' => __( 'This parameter lets you use a YouTube player that does not show a YouTube logo. Set the parameter value to YES to prevent the YouTube logo from displaying in the control bar. Note that a small YouTube text label will still display in the upper-right corner of a paused video when the user\'s mouse pointer hovers over the player', 'testo' )
						),
						'theme' => array(
							'type' => 'select',
							'values' => array(
								'dark' => __( 'Dark theme', 'testo' ),
								'light' => __( 'Light theme', 'testo' )
							),
							'default' => 'dark',
							'name' => __( 'Theme', 'testo' ),
							'desc' => __( 'This parameter indicates whether the embedded player will display player controls (like a play button or volume control) within a dark or light control bar', 'testo' )
						),
						'https' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Force HTTPS', 'testo' ),
							'desc' => __( 'Use HTTPS in player iframe', 'testo' )
						),
						'wmode' => array(
							'default' => '',
							'name'    => __( 'WMode', 'testo' ),
							'desc'    => sprintf( __( 'Here you can specify wmode value for the embed URL. %s Example values: %s, %s', 'testo' ), '<br>', '<b%value>transparent</b>', '<b%value>opaque</b>' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'desc' => __( 'YouTube video player with advanced settings', 'testo' ),
					'example' => 'media',
					'icon' => 'youtube-play'
				),
				// vimeo
				'vimeo' => array(
					'name' => __( 'Vimeo', 'testo' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Url', 'testo' ), 'desc' => __( 'Url of Vimeo page with video', 'testo' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'testo' ),
							'desc' => __( 'Player width', 'testo' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 400,
							'name' => __( 'Height', 'testo' ),
							'desc' => __( 'Player height', 'testo' )
						),
						'poster' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'Poster', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'desc' => __( 'Vimeo video', 'testo' ),
					'example' => 'media',
					'icon' => 'youtube-play'
				),
				// screenr
				'screenr' => array(
					'name' => __( 'Screenr', 'testo' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'default' => '',
							'name' => __( 'Url', 'testo' ),
							'desc' => __( 'Url of Screenr page with video', 'testo' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'testo' ),
							'desc' => __( 'Player width', 'testo' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 400,
							'name' => __( 'Height', 'testo' ),
							'desc' => __( 'Player height', 'testo' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'testo' ),
							'desc' => __( 'Ignore width and height parameters and make player responsive', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'desc' => __( 'Screenr video', 'testo' ),
					'icon' => 'youtube-play'
				),
				// dailymotion
				'dailymotion' => array(
					'name' => __( 'Dailymotion', 'testo' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'default' => '',
							'name' => __( 'Url', 'testo' ),
							'desc' => __( 'Url of Dailymotion page with video', 'testo' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'testo' ),
							'desc' => __( 'Player width', 'testo' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 400,
							'name' => __( 'Height', 'testo' ),
							'desc' => __( 'Player height', 'testo' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'testo' ),
							'desc' => __( 'Ignore width and height parameters and make player responsive', 'testo' )
						),
						'autoplay' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Autoplay', 'testo' ),
							'desc' => __( 'Start the playback of the video automatically after the player load. May not work on some mobile OS versions', 'testo' )
						),
						'background' => array(
							'type' => 'color',
							'default' => '#FFC300',
							'name' => __( 'Background color', 'testo' ),
							'desc' => __( 'HTML color of the background of controls elements', 'testo' )
						),
						'foreground' => array(
							'type' => 'color',
							'default' => '#F7FFFD',
							'name' => __( 'Foreground color', 'testo' ),
							'desc' => __( 'HTML color of the foreground of controls elements', 'testo' )
						),
						'highlight' => array(
							'type' => 'color',
							'default' => '#171D1B',
							'name' => __( 'Highlight color', 'testo' ),
							'desc' => __( 'HTML color of the controls elements\' highlights', 'testo' )
						),
						'logo' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show logo', 'testo' ),
							'desc' => __( 'Allows to hide or show the Dailymotion logo', 'testo' )
						),
						'quality' => array(
							'type' => 'select',
							'values' => array(
								'240'  => '240',
								'380'  => '380',
								'480'  => '480',
								'720'  => '720',
								'1080' => '1080'
							),
							'default' => '380',
							'name' => __( 'Quality', 'testo' ),
							'desc' => __( 'Determines the quality that must be played by default if available', 'testo' )
						),
						'related' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show related videos', 'testo' ),
							'desc' => __( 'Show related videos at the end of the video', 'testo' )
						),
						'info' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show video info', 'testo' ),
							'desc' => __( 'Show videos info (title/author) on the start screen', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'desc' => __( 'Dailymotion video', 'testo' ),
					'icon' => 'youtube-play'
				),
				// audio
				'audio' => array(
					'name' => __( 'Audio', 'testo' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'File', 'testo' ),
							'desc' => __( 'Audio file url. Supported formats: mp3, ogg', 'testo' )
						),
						'width' => array(
							'values' => array(),
							'default' => '100%',
							'name' => __( 'Width', 'testo' ),
							'desc' => __( 'Player width. You can specify width in percents and player will be responsive. Example values: <b%value>200px</b>, <b%value>100&#37;</b>', 'testo' )
						),
						'autoplay' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Autoplay', 'testo' ),
							'desc' => __( 'Play file automatically when page is loaded', 'testo' )
						),
						'loop' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Loop', 'testo' ),
							'desc' => __( 'Repeat when playback is ended', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'desc' => __( 'Custom audio player', 'testo' ),
					'example' => 'media',
					'icon' => 'play-circle'
				),
				// video
				'video' => array(
					'name' => __( 'Video', 'testo' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'File', 'testo' ),
							'desc' => __( 'Url to mp4/flv video-file', 'testo' )
						),
						'poster' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'Poster', 'testo' ),
							'desc' => __( 'Url to poster image, that will be shown before playback', 'testo' )
						),
						'title' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Title', 'testo' ),
							'desc' => __( 'Player title', 'testo' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'testo' ),
							'desc' => __( 'Player width', 'testo' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 300,
							'name' => __( 'Height', 'testo' ),
							'desc' => __( 'Player height', 'testo' )
						),
						'controls' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Controls', 'testo' ),
							'desc' => __( 'Show player controls (play/pause etc.) or not', 'testo' )
						),
						'autoplay' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Autoplay', 'testo' ),
							'desc' => __( 'Play file automatically when page is loaded', 'testo' )
						),
						'loop' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Loop', 'testo' ),
							'desc' => __( 'Repeat when playback is ended', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'desc' => __( 'Custom video player', 'testo' ),
					'example' => 'media',
					'icon' => 'play-circle'
				),
				// custom_video
				'custom_video' => array(
					'name' => __( 'Custom Video', 'testo' ),
					'type' => 'wrap',
					'group' => 'testo',
					'atts' => array(
						'url' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'File', 'testo' ),
							'desc' => __( 'Url to mp4/flv video-file', 'testo' )
						),
						'poster' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'Poster', 'testo' ),
							'desc' => __( 'Video poster', 'testo' )
						),
					),
					'desc' => __( 'Custom video player', 'testo' ),
					'example' => 'media',
					'icon' => 'play-circle'
				),
				// custom_audio
				'custom_audio' => array(
					'name' => __( 'Custom Audio', 'testo' ),
					'type' => 'single',
					'group' => 'testo',
					'atts' => array(
						'url' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'File', 'testo' ),
							'desc' => __( 'Url of audio file', 'testo' )
						),
					),
					'desc' => __( 'Custom audio player', 'testo' ),
					'example' => 'media',
					'icon' => 'play-circle'
				),
				// table
				'table' => array(
					'name' => __( 'Table', 'testo' ),
					'type' => 'mixed',
					'group' => 'content',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'testo' ),
								'style2' => __( 'Style 2', 'testo' ),
							),
							'default' => 'default',
							'name' => __( 'Style', 'testo' ),
							'desc' => __( 'Choose style for this table', 'testo' ) . '%ts_skins_link%'
						),
						'url' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'CSV file', 'testo' ),
							'desc' => __( 'Upload CSV file if you want to create HTML-table from file', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( "<table>\n<tr>\n\t<td>Table</td>\n\t<td>Table</td>\n</tr>\n<tr>\n\t<td>Table</td>\n\t<td>Table</td>\n</tr>\n</table>", 'testo' ),
					'desc' => __( 'Styled table from HTML or CSV file', 'testo' ),
					'icon' => 'table'
				),
				// alert_box
				'alert_box' => array(
					'name' => __( 'Alert Box', 'testo' ),
					'type' => 'single',
					'group' => 'testo',
					'atts' => array(
						'type' => array(
							'type' => 'select',
							'values' => array(
								'success' => __( 'Success', 'testo' ),
								'danger' => __( 'Error', 'testo' ),
								'warning' => __( 'Warning', 'testo' ),
								'info' => __( 'Information', 'testo' ),
							),
							'default' => 'success',
							'name' => __( 'Alert Type', 'testo' ),
							'desc' => __( 'Choose alert type', 'testo' ) . '%ts_skins_link%'
						),
						'text' => array(
							'type' => 'text',
							'default' => '',
							'name' => __( 'Alert Text', 'testo' ),
							'desc' => __( 'Write your confirmation text here', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( "", 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'table'
				),
				// permalink
				'permalink' => array(
					'name' => __( 'Permalink', 'testo' ),
					'type' => 'mixed',
					'group' => 'content other',
					'atts' => array(
						'id' => array(
							'values' => array( ), 'default' => 1,
							'name' => __( 'ID', 'testo' ),
							'desc' => __( 'Post or page ID', 'testo' )
						),
						'target' => array(
							'type' => 'select',
							'values' => array(
								'self' => __( 'Same tab', 'testo' ),
								'blank' => __( 'New tab', 'testo' )
							),
							'default' => 'self',
							'name' => __( 'Target', 'testo' ),
							'desc' => __( 'Link target. blank - link will be opened in new window/tab', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => '',
					'desc' => __( 'Permalink to specified post/page', 'testo' ),
					'icon' => 'link'
				),
				// members
				'members' => array(
					'name' => __( 'Members', 'testo' ),
					'type' => 'wrap',
					'group' => 'other',
					'atts' => array(
						'message' => array(
							'default' => __( 'This content is for registered users only. Please %login%.', 'testo' ),
							'name' => __( 'Message', 'testo' ), 'desc' => __( 'Message for not logged users', 'testo' )
						),
						'color' => array(
							'type' => 'color',
							'default' => '#ffcc00',
							'name' => __( 'Box color', 'testo' ), 'desc' => __( 'This color will applied only to box for not logged users', 'testo' )
						),
						'login_text' => array(
							'default' => __( 'login', 'testo' ),
							'name' => __( 'Login link text', 'testo' ), 'desc' => __( 'Text for the login link', 'testo' )
						),
						'login_url' => array(
							'default' => wp_login_url(),
							'name' => __( 'Login link url', 'testo' ), 'desc' => __( 'Login link url', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Content for logged members', 'testo' ),
					'desc' => __( 'Content for logged in members only', 'testo' ),
					'icon' => 'lock'
				),
				// guests
				'guests' => array(
					'name' => __( 'Guests', 'testo' ),
					'type' => 'wrap',
					'group' => 'other',
					'atts' => array(
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Content for guests', 'testo' ),
					'desc' => __( 'Content for guests only', 'testo' ),
					'icon' => 'user'
				),
				// feed
				'feed' => array(
					'name' => __( 'RSS Feed', 'testo' ),
					'type' => 'single',
					'group' => 'content other',
					'atts' => array(
						'url' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Url', 'testo' ),
							'desc' => __( 'Url to RSS-feed', 'testo' )
						),
						'limit' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 20,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Limit', 'testo' ), 'desc' => __( 'Number of items to show', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'desc' => __( 'Feed grabber', 'testo' ),
					'icon' => 'rss'
				),
				// menu
				'menu' => array(
					'name' => __( 'Menu', 'testo' ),
					'type' => 'single',
					'group' => 'other',
					'atts' => array(
						'name' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Menu name', 'testo' ), 'desc' => __( 'Custom menu name. Ex: Main menu', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'desc' => __( 'Custom menu by name', 'testo' ),
					'icon' => 'bars'
				),
				// subpages
				'subpages' => array(
					'name' => __( 'Sub pages', 'testo' ),
					'type' => 'single',
					'group' => 'other',
					'atts' => array(
						'depth' => array(
							'type' => 'select',
							'values' => array( 1, 2, 3, 4, 5 ), 'default' => 1,
							'name' => __( 'Depth', 'testo' ),
							'desc' => __( 'Max depth level of children pages', 'testo' )
						),
						'p' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Parent ID', 'testo' ),
							'desc' => __( 'ID of the parent page. Leave blank to use current page', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'desc' => __( 'List of sub pages', 'testo' ),
					'icon' => 'bars'
				),
				// siblings
				'siblings' => array(
					'name' => __( 'Siblings', 'testo' ),
					'type' => 'single',
					'group' => 'other',
					'atts' => array(
						'depth' => array(
							'type' => 'select',
							'values' => array( 1, 2, 3 ), 'default' => 1,
							'name' => __( 'Depth', 'testo' ),
							'desc' => __( 'Max depth level', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'desc' => __( 'List of cureent page siblings', 'testo' ),
					'icon' => 'bars'
				),
				// document
				'document' => array(
					'name' => __( 'Document', 'testo' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'url' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'Url', 'testo' ),
							'desc' => __( 'Url to uploaded document. Supported formats: doc, xls, pdf etc.', 'testo' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'testo' ),
							'desc' => __( 'Viewer width', 'testo' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Height', 'testo' ),
							'desc' => __( 'Viewer height', 'testo' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'testo' ),
							'desc' => __( 'Ignore width and height parameters and make viewer responsive', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'desc' => __( 'Document viewer by Google', 'testo' ),
					'icon' => 'file-text'
				),
				// gmap
				'gmap' => array(
					'name' => __( 'Gmap', 'testo' ),
					'type' => 'single',
					'group' => 'media',
					'atts' => array(
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'testo' ),
							'desc' => __( 'Map width', 'testo' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 400,
							'name' => __( 'Height', 'testo' ),
							'desc' => __( 'Map height', 'testo' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'testo' ),
							'desc' => __( 'Ignore width and height parameters and make map responsive', 'testo' )
						),
						'address' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Marker', 'testo' ),
							'desc' => __( 'Address for the marker. You can type it in any language', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'desc' => __( 'Maps by Google', 'testo' ),
					'icon' => 'globe'
				),
				
				// bg_map
				'bg_map' => array(
					'name' => __( 'Background Gmap', 'testo' ),
					'type' => 'single',
					'group' => 'testo',
					'atts' => array(
						'title' => array(
							'type' => 'text',
							'default' => 'How can we help you?',
							'name' => __( 'Title of Map', 'testo' ),
							'desc' => __('Write your map title', 'testo'),
						),
						'latitude' => array(
							'values' => '',
							'default' => '-37.815994',
							'name' => __( 'Latitude', 'testo' ),
							'desc' => __( 'Get Latitude value from this <a href="http://universimmedia.pagesperso-orange.fr/geo/loc.htm" target="_blank">site</a>.', 'testo' )
						),
						'longitude' => array(
							'default' => '144.952676',
							'name' => __( 'Longitude', 'testo' ),
							'desc' => __( 'Get Longitude value from this <a href="http://universimmedia.pagesperso-orange.fr/geo/loc.htm" target="_blank">site</a>.', 'testo' )
						),
						'marker_image' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'Maker Image', 'testo' ),
							'desc' => __( 'Upload maker image', 'testo' )
						),
						'maker_title' => array(
							'type' => 'text',
							'default' => 'Maker Title',
							'name' => __( 'Title of Maker', 'testo' ),
							'desc' => __('Write your maker title', 'testo'),
						),
						'maker_description' => array(
							'type' => 'text',
							'default' => 'Maker Description',
							'name' => __( 'Description of Maker', 'testo' ),
							'desc' => __('Write your maker description', 'testo'),
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1000,
							'step' => 20,
							'default' => 500,
							'name' => __( 'Height', 'testo' ),
							'desc' => __( 'Height of Map', 'testo' )
						)
					),
					'desc' => __( 'Maps by Google', 'testo' ),
					'icon' => 'globe'
				),
				
				// slider
				'slider' => array(
					'name' => __( 'Slider', 'testo' ),
					'type' => 'single',
					'group' => 'gallery',
					'atts' => array(
						'source' => array(
							'type'    => 'image_source',
							'default' => 'none',
							'name'    => __( 'Source', 'testo' ),
							'desc'    => __( 'Choose images source. You can use images from Media library or retrieve it from posts (thumbnails) posted under specified blog category. You can also pick any custom taxonomy', 'testo' )
						),
						'limit' => array(
							'type' => 'slider',
							'min' => -1,
							'max' => 100,
							'step' => 1,
							'default' => 20,
							'name' => __( 'Limit', 'testo' ),
							'desc' => __( 'Maximum number of image source posts (for recent posts, category and custom taxonomy)', 'testo' )
						),
						'link' => array(
							'type' => 'select',
							'values' => array(
								'none'       => __( 'None', 'testo' ),
								'image'      => __( 'Full-size image', 'testo' ),
								'lightbox'   => __( 'Lightbox', 'testo' ),
								'custom'     => __( 'Slide link (added in media editor)', 'testo' ),
								'attachment' => __( 'Attachment page', 'testo' ),
								'post'       => __( 'Post permalink', 'testo' )
							),
							'default' => 'none',
							'name' => __( 'Links', 'testo' ),
							'desc' => __( 'Select which links will be used for images in this gallery', 'testo' )
						),
						'target' => array(
							'type' => 'select',
							'values' => array(
								'self' => __( 'Same window', 'testo' ),
								'blank' => __( 'New window', 'testo' )
							),
							'default' => 'self',
							'name' => __( 'Links target', 'testo' ),
							'desc' => __( 'Open links in', 'testo' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'testo' ), 'desc' => __( 'Slider width (in pixels)', 'testo' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 200,
							'max' => 1600,
							'step' => 20,
							'default' => 300,
							'name' => __( 'Height', 'testo' ), 'desc' => __( 'Slider height (in pixels)', 'testo' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'testo' ),
							'desc' => __( 'Ignore width and height parameters and make slider responsive', 'testo' )
						),
						'title' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show titles', 'testo' ), 'desc' => __( 'Display slide titles', 'testo' )
						),
						'centered' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Center', 'testo' ), 'desc' => __( 'Is slider centered on the page', 'testo' )
						),
						'arrows' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Arrows', 'testo' ), 'desc' => __( 'Show left and right arrows', 'testo' )
						),
						'pages' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Pagination', 'testo' ),
							'desc' => __( 'Show pagination', 'testo' )
						),
						'mousewheel' => array(
							'type' => 'bool',
							'default' => 'yes', 'name' => __( 'Mouse wheel control', 'testo' ),
							'desc' => __( 'Allow to change slides with mouse wheel', 'testo' )
						),
						'autoplay' => array(
							'type' => 'number',
							'min' => 0,
							'max' => 100000,
							'step' => 100,
							'default' => 5000,
							'name' => __( 'Autoplay', 'testo' ),
							'desc' => __( 'Choose interval between slide animations. Set to 0 to disable autoplay', 'testo' )
						),
						'speed' => array(
							'type' => 'number',
							'min' => 0,
							'max' => 20000,
							'step' => 100,
							'default' => 600,
							'name' => __( 'Speed', 'testo' ), 'desc' => __( 'Specify animation speed', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'desc' => __( 'Customizable image slider', 'testo' ),
					'icon' => 'picture-o'
				),
				
				// carousel
				'carousel' => array(
					'name' => __( 'Carousel', 'testo' ),
					'type' => 'single',
					'group' => 'gallery',
					'atts' => array(
						'source' => array(
							'type'    => 'image_source',
							'default' => 'none',
							'name'    => __( 'Source', 'testo' ),
							'desc'    => __( 'Choose images source. You can use images from Media library or retrieve it from posts (thumbnails) posted under specified blog category. You can also pick any custom taxonomy', 'testo' )
						),
						'limit' => array(
							'type' => 'slider',
							'min' => -1,
							'max' => 100,
							'step' => 1,
							'default' => 20,
							'name' => __( 'Limit', 'testo' ),
							'desc' => __( 'Maximum number of image source posts (for recent posts, category and custom taxonomy)', 'testo' )
						),
						'link' => array(
							'type' => 'select',
							'values' => array(
								'none'       => __( 'None', 'testo' ),
								'image'      => __( 'Full-size image', 'testo' ),
								'lightbox'   => __( 'Lightbox', 'testo' ),
								'custom'     => __( 'Slide link (added in media editor)', 'testo' ),
								'attachment' => __( 'Attachment page', 'testo' ),
								'post'       => __( 'Post permalink', 'testo' )
							),
							'default' => 'none',
							'name' => __( 'Links', 'testo' ),
							'desc' => __( 'Select which links will be used for images in this gallery', 'testo' )
						),
						'target' => array(
							'type' => 'select',
							'values' => array(
								'self' => __( 'Same window', 'testo' ),
								'blank' => __( 'New window', 'testo' )
							),
							'default' => 'self',
							'name' => __( 'Links target', 'testo' ),
							'desc' => __( 'Open links in', 'testo' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 100,
							'max' => 1600,
							'step' => 20,
							'default' => 600,
							'name' => __( 'Width', 'testo' ),
							'desc' => __( 'Carousel width (in pixels)', 'testo' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 20,
							'max' => 1600,
							'step' => 20,
							'default' => 100,
							'name' => __( 'Height', 'testo' ),
							'desc' => __( 'Carousel height (in pixels)', 'testo' )
						),
						'responsive' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Responsive', 'testo' ),
							'desc' => __( 'Ignore width and height parameters and make carousel responsive', 'testo' )
						),
						'items' => array(
							'type' => 'number',
							'min' => 1,
							'max' => 20,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Items to show', 'testo' ),
							'desc' => __( 'How much carousel items is visible', 'testo' )
						),
						'scroll' => array(
							'type' => 'number',
							'min' => 1,
							'max' => 20,
							'step' => 1, 'default' => 1,
							'name' => __( 'Scroll number', 'testo' ),
							'desc' => __( 'How much items are scrolled in one transition', 'testo' )
						),
						'title' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show titles', 'testo' ), 'desc' => __( 'Display titles for each item', 'testo' )
						),
						'centered' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Center', 'testo' ), 'desc' => __( 'Is carousel centered on the page', 'testo' )
						),
						'arrows' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Arrows', 'testo' ), 'desc' => __( 'Show left and right arrows', 'testo' )
						),
						'pages' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Pagination', 'testo' ),
							'desc' => __( 'Show pagination', 'testo' )
						),
						'mousewheel' => array(
							'type' => 'bool',
							'default' => 'yes', 'name' => __( 'Mouse wheel control', 'testo' ),
							'desc' => __( 'Allow to rotate carousel with mouse wheel', 'testo' )
						),
						'autoplay' => array(
							'type' => 'number',
							'min' => 0,
							'max' => 100000,
							'step' => 100,
							'default' => 5000,
							'name' => __( 'Autoplay', 'testo' ),
							'desc' => __( 'Choose interval between auto animations. Set to 0 to disable autoplay', 'testo' )
						),
						'speed' => array(
							'type' => 'number',
							'min' => 0,
							'max' => 20000,
							'step' => 100,
							'default' => 600,
							'name' => __( 'Speed', 'testo' ), 'desc' => __( 'Specify animation speed', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'desc' => __( 'Customizable image carousel', 'testo' ),
					'icon' => 'picture-o'
				),
				
				//Featured Lists
				'featured_lists' => 
				array(
					'name' => __( 'Featured Lists', 'testo' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(	
						'title' => array(
							'type' => 'text',
							'default' => '',
							'name' => __( 'Heading of Lists', 'testo' ),
							'desc' => __('Write your featured list heading', 'testo'),
						),					
						'desc' => array(
							'type' => 'textarea',
							'default' => '',
							'name' => __( 'List Description', 'testo' ),
							'desc' => __( '', 'testo' )
						),
					),
					'content' => __( 'Lorem ipsum dol sit  amet et test description..', 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'list'
				),
				//Featured List
				'featured_list' => 
				array(
					'name' => __( 'Featured List', 'testo' ),
					'type' => 'wrap',
					'group' => 'box',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'testo' ),
								'style_2' => __( 'Style 2', 'testo' ),
							),
							'default' => 'Default',
							'name' => __( 'Style', 'testo' ),
							'desc' => __( '', 'testo' )
						),	
						'title' => array(
							'type' => 'text',
							'default' => '',
							'name' => __( 'List Title', 'testo' ),
							'desc' => __('Write your featured list title', 'testo'),
						),					
						'desc' => array(
							'type' => 'textarea',
							'default' => '',
							'name' => __( 'List Description', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'ic_icon' => array(
							'default' => '',
							'name' => __( 'Icon(Iconic Icons)', 'testo' ),
							'desc' => __( 'Example: map-marker ; Copy and Paste your icon class from here <a href="https://useiconic.com/open" target="_blank">site</a> ', 'testo' )
						),
						'icon' => array(
							'type' => 'icon',
							'default' => '',
							'name' => __( 'Choose Icon', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'size' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 40,
							'step' => 1,
							'default' => 14,
							'name' => __( 'Size', 'testo' ),
							'desc' => __( 'Size of Icon', 'testo' )
						),
						'icon_color' => array(
							'type' => 'color',
							'default' => '#fa9000',
							'name' => __( 'Icon color', 'testo' ),
							'desc' => __( 'This color will be applied to the selected icon. Does not works with uploaded icons', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Lorem ipsum dol sit  amet et test description..', 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'list'
				),
				
				//Testimonial group
			    'testimonials' => 
				array(
					'name' => __( 'Testimonials', 'testo' ),
					'type' => 'wrap',
					'group' => 'testo',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'testo' ),
								'style_2' => __( 'Style 2', 'testo' ),
								'style_3' => __( 'Style 3', 'testo' ),
							),
							'default' => 'Default',
							'name' => __( 'Style', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'nav' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Nav', 'testo' ),
							'desc' => __( 'Show nav or not', 'testo' )
						),
						'autoplay' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Auto Play', 'testo' ),
							'desc' => __( 'Auto play on of off', 'testo' )
						),
						'nav_position' => array(
							'type' => 'select',
							'values' => array(
								'left' => __( 'Left', 'testo' ),
								'right' => __( 'Right', 'testo' ),
							),
							'default' => 'right',
							'name' => __( 'Nav Position', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						),
					'content' => __( 'Single testimonial shortcode goes here', 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'recycle'
				),

			//Testimonial
			'testimonial' => 
				array(
					'name' => __( 'Testimonial', 'testo' ),
					'type' => 'wrap',
					'group' => 'testo',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'testo' ),
								'style_2' => __( 'Style 2', 'testo' ),
								'style_3' => __( 'Style 3', 'testo' ),
							),
							'default' => 'Default',

							'name' => __( 'Style', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'name' => array(
							'type' => 'text',
							'default' => 'Nikar avlley',
							'name' => __( 'Name', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'title' => array(
							'type' => 'text',
							'default' => 'rtp',
							'name' => __( 'Title', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'title_color' => array(
							'type' => 'color',
							'default' => '#27293d',
							'name' => __( 'Title color', 'testo' ),
							'desc' => __( 'Title text color', 'testo' )
						),
						'site' => array(
							'type' => 'text',
							'default' => '',
							'name' => __( 'Site', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'site_link' => array(
							'type' => 'text',
							'default' => '#',
							'name' => __( 'Site Link', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'image' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'Upload Photo', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'text_color' => array(
							'type' => 'color',
							'default' => '#676767',
							'name' => __( 'Text color', 'testo' ),
							'desc' => __( 'Text color of description', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Lorem ipsum dol sit  amet et test description..', 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'quote-left'
				),
				
				//frame_message
				'frame_message' => 
				array(
					'name' => __( 'Frame Message', 'testo' ),
					'type' => 'wrap',
					'group' => 'testo',
					'atts' => array(
						'title' => array(
							'default' => '',
							'name' => __( 'Title', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'sub_title' => array(
							'default' => '',
							'name' => __( 'Sub Title', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'button_text' => array(
							'default' => '',
							'name' => __( 'Button Text', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'button_link' => array(
							'default' => '',
							'name' => __( 'Button Link', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Lorem ipsum dol sit  amet et test description..', 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'indent'
				),
				
				//products_search
				'products_search' => 
				array(
					'name' => __( 'Product Search', 'testo' ),
					'type' => 'single',
					'group' => 'testo',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'testo' ),
								'style_2' => __( 'Style 2', 'testo' )
							),
							'default' => 'default',
							'name' => __( 'Style', 'testo' ),
							'desc' => __( 'Choose style for search', 'testo' ) . '%ts_skins_link%'
						),
						'button_text' => array(
							'default' => 'E.g: Herta Berlin Hotel',
							'name' => __( 'Placeholder', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'search_title' => array(
							'default' => '',
							'name' => __( 'Search Title', 'testo' ),
							'desc' => __( '', 'testo' )
						),
					),
					'content' => __( 'product Search', 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'search'
				),
				
				//Icons
				'icons' => 
				array(
					'name' => __( 'Icon', 'testo' ),
					'type' => 'single',
					'group' => 'testo',
					'atts' => array(
						'icon' => array(
							'type' => 'icon',
							'default' => '',
							'name' => __( 'Icon', 'testo' ),
							'desc' => __( 'select icon from here, You can upload custom icon for this box', 'testo' )
						),
						'icon_color' => array(
							'type' => 'color',
							'default' => '#333333',
							'name' => __( 'Icon color', 'testo' ),
							'desc' => __( 'This color will be applied to the selected icon. Does not works with uploaded icons', 'testo' )
						),
						'font_size' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 70,
							'step' => 1,
							'default' => 40,
							'name' => __( 'Font Size', 'testo' ),
							'desc' => __( 'Font size of Title(in pixels)', 'testo' )
						),
						'icon_align' => array(
							'type' => 'select',
							'values' => array(
								'left'   => __( 'Left', 'testo' ),
								'center' => __( 'Center', 'testo' ),
								'right'  => __( 'Right', 'testo' )
							),
							'default' => 'center',
							'name' => __( 'Icon alignment', 'testo' ),
							'desc' => __( 'Select the icon alignment', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Lorem ipsum dol sit  amet et test description..', 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'indent'
				),
				
				//Icons
				'icons_info' => 
				array(
					'name' => __( 'Icon With Info', 'testo' ),
					'type' => 'single',
					'group' => 'testo',
					'atts' => array(
						'icon' => array(
							'type' => 'icon',
							'default' => '',
							'name' => __( 'Icon', 'testo' ),
							'desc' => __( 'select icon from here, You can upload custom icon for this box', 'testo' )
						),
						'icon_color' => array(
							'type' => 'color',
							'default' => '#f3b723',
							'name' => __( 'Icon color', 'testo' ),
							'desc' => __( 'This color will be applied to the selected icon. Does not works with uploaded icons', 'testo' )
						),
						'font_size' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 70,
							'step' => 1,
							'default' => 28,
							'name' => __( 'Font Size', 'testo' ),
							'desc' => __( 'Font size of icon(in pixels)', 'testo' )
						),
						'title' => array(
							'type' => 'text',
							'default' => 'Australia Office',
							'name' => __( 'Title', 'testo' ),
							'desc' => __( 'Title of icon', 'testo' )
						),
						'icon_des' => array(
							'type' => 'text',
							'default' => 'PO Box 16122 Collins Street West Victoria',
							'name' => __( 'Description', 'testo' ),
							'desc' => __( 'Description of icon', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Lorem ipsum dol sit  amet et test description..', 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'indent'
				),
				
				//counter
				'counters' => 
				array(
					'name' => __( 'Counters', 'testo' ),
					'type' => 'wrap',
					'group' => 'testo',
					'atts' => array(
						'title' => array(
							'type' => 'text',
							'default' => '',
							'name' => __( 'Title', 'testo' ),
							'desc' => __( 'Heading of counters', 'testo' )
						),
						'background' => array(
							'type' => 'color',
							'default' => '#f7f8f9',
							'name' => __( 'Background', 'testo' ),
							'desc' => __( 'Background of main section', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'counter description', 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'check-square-o'
				),
				
				//counter
				'counter_up' => 
				array(
					'name' => __( 'Counter', 'testo' ),
					'type' => 'single',
					'group' => 'testo',
					'atts' => array(
						'number' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 100000,
							'step' => 1,
							'default' => 1000,
							'name' => __( 'Total number', 'testo' ),
							'desc' => __( 'This is count up from zero.', 'testo' )
						),
						'title' => array(
							'type' => 'text',
							'default' => '',
							'name' => __( 'Title', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'flat_icon' => array(
							'type' => 'text',
							'default' => '',
							'name' => __( 'Flat Icon', 'testo' ),
							'desc' => __( 'Write your flat icon class here; example: shopping-basket', 'testo' )
						),
						'icon' => array(
							'type' => 'icon',
							'default' => '',
							'name' => __( 'Icon', 'testo' ),
							'desc' => __( 'select icon from here, You can upload custom icon for this box', 'testo' )
						),
						'icon_color' => array(
							'type' => 'color',
							'default' => '#f18167',
							'name' => __( 'Icon color', 'testo' ),
							'desc' => __( 'This color will be applied to the selected icon. Does not works with uploaded icons', 'testo' )
						),
						'font_size' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 70,
							'step' => 1,
							'default' => 28,
							'name' => __( 'Font Size', 'testo' ),
							'desc' => __( 'Font size of icon(in pixels)', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'counter description', 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'check-square-o'
				),
				
				//countdown
				'countdown' => 
				array(
					'name' => __( 'Countdown', 'testo' ),
					'type' => 'single',
					'group' => 'testo',
					'atts' => array(
						'date' => array(
							'type' => 'text',
							'default' => '2016/12/12',
							'name' => __( 'Date', 'testo' ),
							'desc' => __( 'Formate: 2016/01/01(Y/m/d)', 'testo' )
						),
					),
					'content' => __( 'counter description', 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'check-square-o'
				),
				
				//offer
				'offer' => 
				array(
					'name' => __( 'Offer', 'testo' ),
					'type' => 'wrap',
					'group' => 'testo',
					'atts' => array(
						'title' => array(
							'type' => 'text',
							'default' => '',
							'name' => __( 'Title', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'desc' => array(
							'type' => 'text',
							'default' => '',
							'name' => __( 'Description', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'button_text' => array(
							'type' => 'text',
							'default' => '',
							'name' => __( 'Button Text', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'form_action' => array(
							'type' => 'text',
							'default' => '',
							'name' => __( 'Form Action', 'testo' ),
							'desc' => __( '', 'testo' )
						),
					),
					'content' => __( 'Offer list shortcode goes here', 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'check-square-o'
				),
				
				//offer_list
				'offer_list' => 
				array(
					'name' => __( 'Offer List', 'testo' ),
					'type' => 'single',
					'group' => 'testo',
					'atts' => array(
						'title' => array(
							'type' => 'text',
							'default' => '',
							'name' => __( 'Title', 'testo' ),
							'desc' => __( '', 'testo' )
						),
					),
					'content' => __( 'list of offers', 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'check-square-o'
				),
				
				//bg_animation
				'bg_animation' => 
				array(
					'name' => __( 'Background Animation', 'testo' ),
					'type' => 'single',
					'group' => 'testo',
					'atts' => array(
						'image' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'Upload Image', 'testo' ),
							'desc' => __( 'image for background', 'testo' )
						),
						'animation' => array(
							'type' => 'select',
							'values' => array(
								'slideInLeft' => __( 'slideInLeft', 'testo' ),
								'slideInRight' => __( 'slideInRight', 'testo' ),
								'slideInUp' => __( 'slideInUp', 'testo' ),
								'slideInDown' => __( 'slideInDown', 'testo' ),
							),
							'default' => 'slideInRight',
							'name' => __( 'Animation', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => -1,
							'max' => 1000,
							'step' => 1,
							'default' => '',
							'name' => __( 'Height', 'testo' ),
							'desc' => __( 'Height of background', 'testo' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => -1,
							'max' => 2000,
							'step' => 1,
							'default' => '',
							'name' => __( 'Width', 'testo' ),
							'desc' => __( 'Width of background', 'testo' )
						),
						'left' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 100,
							'step' => 1,
							'default' => '',
							'name' => __( 'Left', 'testo' ),
							'desc' => __( 'Position in %', 'testo' )
						),
						'right' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 100,
							'step' => 1,
							'default' => '',
							'name' => __( 'Right', 'testo' ),
							'desc' => __( 'Position in %', 'testo' )
						),
						'top' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 1000,
							'step' => 1,
							'default' => '',
							'name' => __( 'Top', 'testo' ),
							'desc' => __( 'Position in px', 'testo' )
						),
						'bottom' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 1000,
							'step' => 1,
							'default' => '',
							'name' => __( 'Bottom', 'testo' ),
							'desc' => __( 'Position in px', 'testo' )
						),
					),
					'content' => __( 'list of offers', 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'check-square-o'
				),
				
				//Partners
				'partners' => 
				array(
					'name' => __( 'Partners', 'testo' ),
					'type' => 'wrap',
					'group' => 'testo',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'testo' ),
								'style_2' => __( 'Style 2', 'testo' ),
							),
							'default' => 'Default',
							'name' => __( 'Style', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Single partner shortcode here...', 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'users'
				),
				
				//Partner
				'partner' => 
				array(
					'name' => __( 'Partner', 'testo' ),
					'type' => 'single',
					'group' => 'testo',
					'atts' => array(
						'image' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'Upload Partners Image', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'image_link' => array(
							'type' => 'text',
							'default' => '#',
							'name' => __( 'Image Link', 'testo' ),
							'desc' => __('', 'testo'),
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'partner description', 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'users'
				),
				
				// custom_gallery
				'custom_gallery' => array(
					'name' => __( 'Gallery', 'testo' ),
					'type' => 'single',
					'group' => 'gallery',
					'atts' => array(
						'source' => array(
							'type'    => 'image_source',
							'default' => 'none',
							'name'    => __( 'Source', 'testo' ),
							'desc'    => __( 'Choose images source. You can use images from Media library or retrieve it from posts (thumbnails) posted under specified blog category. You can also pick any custom taxonomy', 'testo' )
						),
						'limit' => array(
							'type' => 'slider',
							'min' => -1,
							'max' => 100,
							'step' => 1,
							'default' => 20,
							'name' => __( 'Limit', 'testo' ),
							'desc' => __( 'Maximum number of image source posts (for recent posts, category and custom taxonomy)', 'testo' )
						),
						'link' => array(
							'type' => 'select',
							'values' => array(
								'none'       => __( 'None', 'testo' ),
								'image'      => __( 'Full-size image', 'testo' ),
								'lightbox'   => __( 'Lightbox', 'testo' ),
								'custom'     => __( 'Slide link (added in media editor)', 'testo' ),
								'attachment' => __( 'Attachment page', 'testo' ),
								'post'       => __( 'Post permalink', 'testo' )
							),
							'default' => 'none',
							'name' => __( 'Links', 'testo' ),
							'desc' => __( 'Select which links will be used for images in this gallery', 'testo' )
						),
						'target' => array(
							'type' => 'select',
							'values' => array(
								'self' => __( 'Same window', 'testo' ),
								'blank' => __( 'New window', 'testo' )
							),
							'default' => 'self',
							'name' => __( 'Links target', 'testo' ),
							'desc' => __( 'Open links in', 'testo' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 1600,
							'step' => 10,
							'default' => 90,
							'name' => __( 'Width', 'testo' ), 'desc' => __( 'Single item width (in pixels)', 'testo' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 1600,
							'step' => 10,
							'default' => 90,
							'name' => __( 'Height', 'testo' ), 'desc' => __( 'Single item height (in pixels)', 'testo' )
						),
						'column' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 6,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Column', 'testo' ), 'desc' => __( 'Gallery column', 'testo' )
						),
						'title' => array(
							'type' => 'select',
							'values' => array(
								'never' => __( 'Never', 'testo' ),
								'hover' => __( 'On mouse over', 'testo' ),
								'always' => __( 'Always', 'testo' )
							),
							'default' => 'hover',
							'name' => __( 'Show titles', 'testo' ),
							'desc' => __( 'Title display mode', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'desc' => __( 'Customizable image gallery', 'testo' ),
					'icon' => 'picture-o'
				),
				
				//progress_bar
				'progress_bar' => 
				array(
					'name' => __( 'Progress Bar', 'testo' ),
					'type' => 'single',
					'group' => 'testo',
					'atts' => array(
						'title' => array(
							'type' => 'text',
							'values' => '',
							'default' => 'HTML',
							'name' => __( 'Title', 'testo' ),
							'desc' => __( 'chart title', 'testo' )
						),
						'title_color' => array(
							'type' => 'color',
							'default' => '#262626',
							'name' => __( 'Title Color', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'title_font_size' => array(
							'type' => 'slider',
							'min' => 12,
							'max' => 60,
							'step' => 1,
							'default' => 24,
							'name' => __( 'Title Font Size', 'testo' ),
							'desc' => __( 'font size in px', 'testo' )
						),
						'percent' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 100,
							'step' => 1,
							'default' => 70,
							'name' => __( 'Percent', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 50,
							'step' => 1,
							'default' => 20,
							'name' => __( 'Height', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'bar_color' => array(
							'type' => 'color',
							'default' => '#f5f5f5',
							'name' => __( 'Bar Color', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'activecolor' => array(
							'type' => 'color',
							'default' => '#f3b723',
							'name' => __( 'Active Color', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'text_color' => array(
							'type' => 'color',
							'default' => '#ffffff',
							'name' => __( 'Text Color', 'testo' ),
							'desc' => __( '', 'testo' )
						),
					),
					'desc' => __( '', 'testo' ),
					'icon' => 'users'
				),
				
				// contact_info
				'contact_address' => array(
					'name' => __( 'Contact Address', 'testo' ),
					'type' => 'single',
					'group' => 'testo',
					'atts' => array(
						'title' => array(
							'type' => 'text',
							'default' => '',
							'name' => __( 'Title', 'testo' ),
							'desc' => __( 'Title of address', 'testo' )
						),
						'address' => array(
							'type' => 'textarea',
							'values' => '',
							'default' => '',
							'name' => __( 'Address', 'testo' ),
							'desc' => __( 'Address of contact', 'testo' )
						),
					),
					'desc' => __( '', 'testo' ),
					'icon' => 'map'
				),
				
				// bg_content
				'bg_content' => array(
					'name' => __( 'Content With Background Image', 'testo' ),
					'type' => 'wrap',
					'group' => 'testo',
					'atts' => array(						
						'bg' => array(
							'type' => 'upload',
							'values' => '',
							'default' => '',
							'name' => __( 'Background', 'testo' ),
							'desc' => __( 'background image of main div', 'testo' )
						),
					),
					'desc' => __( 'content goes here...', 'testo' ),
					'icon' => 'image'
				),
				
				// text_color
				'text_color' => array(
					'name' => __( 'Text Color', 'testo' ),
					'type' => 'wrap',
					'group' => 'testo',
					'atts' => array(						
						'color' => array(
							'type' => 'color',
							'values' => '',
							'default' => '#ef4416',
							'name' => __( 'Color', 'testo' ),
							'desc' => __( 'Select color of text', 'testo' )
						),
					),
					'desc' => __( 'text goes here...', 'testo' ),
					'icon' => 'image'
				),
				
				// typed
				'typed' => array(
					'name' => __( 'Typed Text', 'testo' ),
					'type' => 'single',
					'group' => 'testo',
					'atts' => array(						
						'color' => array(
							'type' => 'color',
							'values' => '',
							'default' => '#27293d',
							'name' => __( 'Color', 'testo' ),
							'desc' => __( 'Select color of text', 'testo' )
						),
						'text1' => array(
							'type' => 'text',
							'values' => '',
							'default' => '',
							'name' => __( 'Text 1', 'testo' ),
							'desc' => __( 'Type seperate by comma', 'testo' )
						),
						'text2' => array(
							'type' => 'text',
							'values' => '',
							'default' => '',
							'name' => __( 'Text 2', 'testo' ),
							'desc' => __( 'Type seperate by comma', 'testo' )
						),
						'text3' => array(
							'type' => 'text',
							'values' => '',
							'default' => '',
							'name' => __( 'Text 3', 'testo' ),
							'desc' => __( 'Type seperate by comma', 'testo' )
						),
						'text4' => array(
							'type' => 'text',
							'values' => '',
							'default' => '',
							'name' => __( 'Text 4', 'testo' ),
							'desc' => __( 'Type seperate by comma', 'testo' )
						),
					),
					'desc' => __( 'text goes here...', 'testo' ),
					'icon' => 'image'
				),
				
				// socials_icons
				'socials_icons' => array(
					'name' => __( 'Social Icons', 'testo' ),
					'type' => 'wrap',
					'group' => 'testo',
					'atts' => array(						
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'testo' ),
							),
							'default' => 'default',
							'name' => __( 'Style', 'testo' ),
							'desc' => __( 'Choose style for this icon', 'testo' ) . '%ts_skins_link%'
						),						
					),
					'desc' => __( 'Socials Icons', 'testo' ),
					'icon' => 'users'
				),
				
				// socials_icon
				'socials_icon' => array(
					'name' => __( 'Social Icon', 'testo' ),
					'type' => 'single',
					'group' => 'testo',
					'atts' => array(						
						'name' => array(
							'type' => 'text',
							'values' => '',
							'default' => '',
							'name' => __( 'Name', 'testo' ),
							'desc' => __( 'Social Icon name', 'testo' )
						),
						'link' => array(
							'type' => 'text',
							'values' => '',
							'default' => '#',
							'name' => __( 'Social Link', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'icon' => array(
							'type' => 'icon',
							'values' => '',
							'default' => '',
							'name' => __( 'Select Icon', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'size' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 40,
							'step' => 1,
							'default' => 12,
							'name' => __( 'Size', 'testo' ),
							'desc' => __( 'Size of Icon', 'testo' )
						),
						
					),
					'desc' => __( 'Socials Icon', 'testo' ),
					'icon' => 'users'
				),
				
				//superslides
				'superslides' => 
				array(
					'name' => __( 'Super Sliders', 'testo' ),
					'type' => 'wrap',
					'group' => 'testo',
					'atts' => array(
						'class' => array(
							'type' => 'text',
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( '', 'testo' )
						),
					),
					'content' => __( 'Super slide item shortcode goes here', 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'check-square-o'
				),
				
				//superslide
				'superslide' => 
				array(
					'name' => __( 'Super Slider', 'testo' ),
					'type' => 'single',
					'group' => 'testo',
					'atts' => array(
						'image' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'Upload Slider Image', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'title' => array(
							'type' => 'text',
							'default' => '',
							'name' => __( 'Title', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'description' => array(
							'type' => 'text',
							'default' => '',
							'name' => __( 'Description', 'testo' ),
							'desc' => __( '', 'testo' )
						),
					),
					'content' => __( '', 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'check-square-o'
				),
				
				//faqs
				'faqs' => 
				array(
					'name' => __( 'FAQs', 'testo' ),
					'type' => 'single',
					'group' => 'testo',
					'atts' => array(
						'title' => array(
							'type' => 'text',
							'default' => '',
							'name' => __( 'Question', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'description' => array(
							'type' => 'textarea',
							'default' => '',
							'name' => __( 'Answer', 'testo' ),
							'desc' => __( '', 'testo' )
						),
					),
					'content' => __( '', 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'check-square-o'
				),
				
				// callout
				'callout' => array(
					'name' => __( 'Callout', 'testo' ),
					'type' => 'wrap',
					'group' => 'testo',
					'atts' => array(						
						'title' => array(
							'type' => 'text',
							'values' => '',
							'default' => '',
							'name' => __( 'Title', 'testo' ),
							'desc' => __( 'Title', 'testo' )
						),
						'button_text' => array(
							'type' => 'text',
							'values' => '',
							'default' => '',
							'name' => __( 'Button Text', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'button_link' => array(
							'type' => 'text',
							'values' => '',
							'default' => '#',
							'name' => __( 'Button Link', 'testo' ),
							'desc' => __( '', 'testo' )
						),						
					),
					'desc' => __( 'Callout', 'testo' ),
					'icon' => 'users'
				),
				
				// posts
				'posts' => array(
					'name' => __( 'Posts', 'testo' ),
					'type' => 'single',
					'group' => 'other',
					'atts' => array(
						'template' => array(
							'default' => 'templates/default-loop.php', 'name' => __( 'Template', 'testo' ),
							'desc' => __( '<b>Do not change this field value if you do not understand description below.</b><br/>Relative path to the template file. Default templates is placed under the plugin directory (templates folder). You can copy it under your theme directory and modify as you want. You can use following default templates that already available in the plugin directory:<br/><b%value>templates/default-loop.php</b> - posts loop<br/><b%value>templates/teaser-loop.php</b> - posts loop with thumbnail and title<br/><b%value>templates/single-post.php</b> - single post template<br/><b%value>templates/list-loop.php</b> - unordered list with posts titles', 'testo' )
						),
						'id' => array(
							'default' => '',
							'name' => __( 'Post ID\'s', 'testo' ),
							'desc' => __( 'Enter comma separated ID\'s of the posts that you want to show', 'testo' )
						),
						'posts_per_page' => array(
							'type' => 'number',
							'min' => -1,
							'max' => 10000,
							'step' => 1,
							'default' => get_option( 'posts_per_page' ),
							'name' => __( 'Posts per page', 'testo' ),
							'desc' => __( 'Specify number of posts that you want to show. Enter -1 to get all posts', 'testo' )
						),
						'post_type' => array(
							'type' => 'select',
							'multiple' => true,
							'values' => Ts_Tools::get_types(),
							'default' => 'post',
							'name' => __( 'Post types', 'testo' ),
							'desc' => __( 'Select post types. Hold Ctrl key to select multiple post types', 'testo' )
						),
						'taxonomy' => array(
							'type' => 'select',
							'values' => Ts_Tools::get_taxonomies(),
							'default' => 'category',
							'name' => __( 'Taxonomy', 'testo' ),
							'desc' => __( 'Select taxonomy to show posts from', 'testo' )
						),
						'tax_term' => array(
							'type' => 'select',
							'multiple' => true,
							'values' => Ts_Tools::get_terms( 'category' ),
							'default' => '',
							'name' => __( 'Terms', 'testo' ),
							'desc' => __( 'Select terms to show posts from', 'testo' )
						),
						'tax_operator' => array(
							'type' => 'select',
							'values' => array( 'IN', 'NOT IN', 'AND' ),
							'default' => 'IN', 'name' => __( 'Taxonomy term operator', 'testo' ),
							'desc' => __( 'IN - posts that have any of selected categories terms<br/>NOT IN - posts that is does not have any of selected terms<br/>AND - posts that have all selected terms', 'testo' )
						),
						// 'author' => array(
						// 	'type' => 'select',
						// 	'multiple' => true,
						// 	'values' => Ts_Tools::get_users(),
						// 	'default' => 'default',
						// 	'name' => __( 'Authors', 'testo' ),
						// 	'desc' => __( 'Choose the authors whose posts you want to show. Enter here comma-separated list of users (IDs). Example: 1,7,18', 'testo' )
						// ),
						'author' => array(
							'default' => '',
							'name' => __( 'Authors', 'testo' ),
							'desc' => __( 'Enter here comma-separated list of author\'s IDs. Example: 1,7,18', 'testo' )
						),
						'meta_key' => array(
							'default' => '',
							'name' => __( 'Meta key', 'testo' ),
							'desc' => __( 'Enter meta key name to show posts that have this key', 'testo' )
						),
						'offset' => array(
							'type' => 'number',
							'min' => 0,
							'max' => 10000,
							'step' => 1, 'default' => 0,
							'name' => __( 'Offset', 'testo' ),
							'desc' => __( 'Specify offset to start posts loop not from first post', 'testo' )
						),
						'order' => array(
							'type' => 'select',
							'values' => array(
								'desc' => __( 'Descending', 'testo' ),
								'asc' => __( 'Ascending', 'testo' )
							),
							'default' => 'DESC',
							'name' => __( 'Order', 'testo' ),
							'desc' => __( 'Posts order', 'testo' )
						),
						'orderby' => array(
							'type' => 'select',
							'values' => array(
								'none' => __( 'None', 'testo' ),
								'id' => __( 'Post ID', 'testo' ),
								'author' => __( 'Post author', 'testo' ),
								'title' => __( 'Post title', 'testo' ),
								'name' => __( 'Post slug', 'testo' ),
								'date' => __( 'Date', 'testo' ), 'modified' => __( 'Last modified date', 'testo' ),
								'parent' => __( 'Post parent', 'testo' ),
								'rand' => __( 'Random', 'testo' ), 'comment_count' => __( 'Comments number', 'testo' ),
								'menu_order' => __( 'Menu order', 'testo' ), 'meta_value' => __( 'Meta key values', 'testo' ),
							),
							'default' => 'date',
							'name' => __( 'Order by', 'testo' ),
							'desc' => __( 'Order posts by', 'testo' )
						),
						'post_parent' => array(
							'default' => '',
							'name' => __( 'Post parent', 'testo' ),
							'desc' => __( 'Show childrens of entered post (enter post ID)', 'testo' )
						),
						'post_status' => array(
							'type' => 'select',
							'values' => array(
								'publish' => __( 'Published', 'testo' ),
								'pending' => __( 'Pending', 'testo' ),
								'draft' => __( 'Draft', 'testo' ),
								'auto-draft' => __( 'Auto-draft', 'testo' ),
								'future' => __( 'Future post', 'testo' ),
								'private' => __( 'Private post', 'testo' ),
								'inherit' => __( 'Inherit', 'testo' ),
								'trash' => __( 'Trashed', 'testo' ),
								'any' => __( 'Any', 'testo' ),
							),
							'default' => 'publish',
							'name' => __( 'Post status', 'testo' ),
							'desc' => __( 'Show only posts with selected status', 'testo' )
						),
						'show_post_thumb' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Show Thumb Image', 'testo' ),
							'desc' => __( 'Want to show or not thumb image', 'testo' )
						),
						'ignore_sticky_posts' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Ignore sticky', 'testo' ),
							'desc' => __( 'Select Yes to ignore posts that is sticked', 'testo' )
						)
					),
					'desc' => __( 'Custom posts query with customizable template', 'testo' ),
					'icon' => 'th-list'
				),
				// portfolios
				'portfolios' => array(
					'name' => __( 'Portfolios', 'testo' ),
					'type' => 'single',
					'group' => 'testo',
					'atts' => array(
						'template' => array(
							'default' => 'templates/portfolio-loop.php', 'name' => __( 'Template', 'testo' ),
							'desc' => __( '<b>Do not change this field value if you do not understand description below.</b><br/>Relative path to the template file. Default templates is placed under the plugin directory (templates folder). You can copy it under your theme directory and modify as you want. You can use following default templates that already available in the plugin directory:<br/><b%value>templates/portfolio-loop.php</b> - portfolios loop<br/><b%value>templates/teaser-loop.php</b> - posts loop with thumbnail and title<br/><b%value>templates/single-post.php</b> - single post template<br/><b%value>templates/list-loop.php</b> - unordered list with posts titles', 'testo' )
						),
						'portfolio_style' => array(
							'type' => 'select',
							'values' => array(
								'grid' => __( 'Grid', 'testo' ),
								'masonry' => __( 'Masonry', 'testo' ),
								'gutter' => __( 'Grid gutter', 'testo' ),
								'masonry_gutter' => __( 'Masonry gutter', 'testo' ),
							),
							'default' => 'gutter',
							'name' => __( 'Gallery Style', 'testo' ),
							'desc' => __( 'select your gallery style', 'testo' )
						),
						'id' => array(
							'default' => '',
							'name' => __( 'Portfolio ID\'s', 'testo' ),
							'desc' => __( 'Enter comma separated ID\'s of the portfolios that you want to show', 'testo' )
						),
						'posts_per_page' => array(
							'type' => 'number',
							'min' => -1,
							'max' => 10000,
							'step' => 1,
							'default' => get_option( 'posts_per_page' ),
							'name' => __( 'Portfolios per page', 'testo' ),
							'desc' => __( 'Specify number of portfolios that you want to show. Enter -1 to get all portfolios', 'testo' )
						),
						'column' => array(
							'type' => 'number',
							'min' => 1,
							'max' => 4,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Column', 'testo' ),
							'desc' => __( 'Column number', 'testo' )
						),
						'post_type' => array(
							'type' => 'select',
							'multiple' => true,
							'values' => Ts_Tools::get_types(),
							'default' => 'portfolio',
							'name' => __( 'Post types', 'testo' ),
							'desc' => __( 'Select post types. Hold Ctrl key to select multiple post types', 'testo' )
						),
						'taxonomy' => array(
							'type' => 'select',
							'values' => Ts_Tools::get_taxonomies(),
							'default' => 'category',
							'name' => __( 'Taxonomy', 'testo' ),
							'desc' => __( 'Select taxonomy to show portfolio from', 'testo' )
						),
						'tax_term' => array(
							'type' => 'select',
							'multiple' => true,
							'values' => Ts_Tools::get_terms( 'category' ),
							'default' => '',
							'name' => __( 'Terms', 'testo' ),
							'desc' => __( 'Select terms to show portfolio from', 'testo' )
						),
						'tax_operator' => array(
							'type' => 'select',
							'values' => array( 'IN', 'NOT IN', 'AND' ),
							'default' => 'IN', 'name' => __( 'Taxonomy term operator', 'testo' ),
							'desc' => __( 'IN - portfolios that have any of selected categories terms<br/>NOT IN - portfolios that is does not have any of selected terms<br/>AND - portfolios that have all selected terms', 'testo' )
						),
						'author' => array(
							'default' => '',
							'name' => __( 'Authors', 'testo' ),
							'desc' => __( 'Enter here comma-separated list of author\'s IDs. Example: 1,7,18', 'testo' )
						),
						'meta_key' => array(
							'default' => '',
							'name' => __( 'Meta key', 'testo' ),
							'desc' => __( 'Enter meta key name to show portfolios that have this key', 'testo' )
						),
						'offset' => array(
							'type' => 'number',
							'min' => 0,
							'max' => 10000,
							'step' => 1, 'default' => 0,
							'name' => __( 'Offset', 'testo' ),
							'desc' => __( 'Specify offset to start portfolios loop not from first portfolio', 'testo' )
						),
						'order' => array(
							'type' => 'select',
							'values' => array(
								'desc' => __( 'Descending', 'testo' ),
								'asc' => __( 'Ascending', 'testo' )
							),
							'default' => 'DESC',
							'name' => __( 'Order', 'testo' ),
							'desc' => __( 'Portfolios order', 'testo' )
						),
						'orderby' => array(
							'type' => 'select',
							'values' => array(
								'none' => __( 'None', 'testo' ),
								'id' => __( 'Portfolio ID', 'testo' ),
								'author' => __( 'Portfolio author', 'testo' ),
								'title' => __( 'Portfolio title', 'testo' ),
								'name' => __( 'Portfolio slug', 'testo' ),
								'date' => __( 'Date', 'testo' ), 'modified' => __( 'Last modified date', 'testo' ),
								'parent' => __( 'Portfolio parent', 'testo' ),
								'rand' => __( 'Random', 'testo' ), 'comment_count' => __( 'Comments number', 'testo' ),
								'menu_order' => __( 'Menu order', 'testo' ), 'meta_value' => __( 'Meta key values', 'testo' ),
							),
							'default' => 'date',
							'name' => __( 'Order by', 'testo' ),
							'desc' => __( 'Order portfolios by', 'testo' )
						),
						'post_parent' => array(
							'default' => '',
							'name' => __( 'Portfolio parent', 'testo' ),
							'desc' => __( 'Show childrens of entered portfolio (enter portfolio ID)', 'testo' )
						),
						'post_status' => array(
							'type' => 'select',
							'values' => array(
								'publish' => __( 'Published', 'testo' ),
								'pending' => __( 'Pending', 'testo' ),
								'draft' => __( 'Draft', 'testo' ),
								'auto-draft' => __( 'Auto-draft', 'testo' ),
								'future' => __( 'Future portfolio', 'testo' ),
								'private' => __( 'Private portfolio', 'testo' ),
								'inherit' => __( 'Inherit', 'testo' ),
								'trash' => __( 'Trashed', 'testo' ),
								'any' => __( 'Any', 'testo' ),
							),
							'default' => 'publish',
							'name' => __( 'Portfolio status', 'testo' ),
							'desc' => __( 'Show only posts with selected status', 'testo' )
						),
						'ignore_sticky_posts' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Ignore sticky', 'testo' ),
							'desc' => __( 'Select Yes to ignore portfolios that is sticked', 'testo' )
						),
						'filter_show_top' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Filter Show Top', 'testo' ),
							'desc' => __( 'Showing Filter in top of portfolios', 'testo' )
						),
						'filter_show_bottom' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Filter Show Bottom', 'testo' ),
							'desc' => __( 'Showing Filter in bottom of portfolios', 'testo' )
						)
					),
					'desc' => __( 'Custom portfolios query with customizable template', 'testo' ),
					'icon' => 'th-list'
				),
				// angle_background_shape
				'angle_background_shape' => array(
					'name' => __( 'Angle bg Shape', 'testo' ),
					'type' => 'single',
					'group' => 'testo',
					'atts' => array(
						'background' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#fcc71f',
							'name' => __( 'Background', 'testo' ),
							'desc' => __( 'Angle background color', 'testo' )
						),
						'position' => array(
							'type' => 'select',
							'values' => array(
								'left_top' => __( 'Left Top', 'testo' ),
								'left_bottom' => __( 'Left Bottom', 'testo' ),
								'right_top' => __( 'Right Top', 'testo' ),
								'right_bottom' => __( 'Right Bottom', 'testo' ),
							),
							'default' => 'left_top',
							'name' => __( 'Position', 'testo' ),
							'desc' => __( 'Position of angle background', 'testo' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 1000,
							'step' => 10,
							'default' => 110,
							'name' => __( 'Height', 'testo' ),
							'desc' => __( 'Choose height', 'testo' )
						),
						'width' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 1000,
							'step' => 10,
							'default' => 220,
							'name' => __( 'Width', 'testo' ),
							'desc' => __( 'Choose width', 'testo' )
						),
					),
					'content' => __( '', 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'pencil'
				),
				// products
				'products' => array(
					'name' => __( 'Products', 'testo' ),
					'type' => 'single',
					'group' => 'other',
					'atts' => array(
						'template' => array(
							'default' => 'templates/product-loop.php', 'name' => __( 'Template', 'testo' ),
							'desc' => __( '<b>Do not change this field value if you do not understand description below.</b><br/>Relative path to the template file. Default templates is placed under the plugin directory (templates folder). You can copy it under your theme directory and modify as you want. You can use following default templates that already available in the plugin directory:<br/><b%value>templates/product-loop.php</b> - default loop<br/>', 'testo' )
						),
						'id' => array(
							'default' => '',
							'name' => __( 'Post ID\'s', 'testo' ),
							'desc' => __( 'Enter comma separated ID\'s of the products that you want to show', 'testo' )
						),
						'posts_per_page' => array(
							'type' => 'number',
							'min' => -1,
							'max' => 10000,
							'step' => 1,
							'default' => get_option( 'posts_per_page' ),
							'name' => __( 'Products per page', 'testo' ),
							'desc' => __( 'Specify number of products that you want to show. Enter -1 to get all products', 'testo' )
						),
						'column' => array(
							'type' => 'number',
							'min' => -1,
							'max' => 4,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Column', 'testo' ),
							'desc' => __( 'Column of products', 'testo' )
						),
						'taxonomy' => array(
							'type' => 'select',
							'values' => Ts_Tools::get_taxonomies(),
							'default' => 'category',
							'name' => __( 'Taxonomy', 'testo' ),
							'desc' => __( 'Select taxonomy to show products from', 'testo' )
						),
						'tax_term' => array(
							'type' => 'select',
							'multiple' => true,
							'values' => Ts_Tools::get_terms( 'category' ),
							'default' => '',
							'name' => __( 'Terms', 'testo' ),
							'desc' => __( 'Select terms to show products from', 'testo' )
						),
						'tax_operator' => array(
							'type' => 'select',
							'values' => array( 'IN', 'NOT IN', 'AND' ),
							'default' => 'IN', 'name' => __( 'Taxonomy term operator', 'testo' ),
							'desc' => __( 'IN - products that have any of selected categories terms<br/>NOT IN - products that is does not have any of selected terms<br/>AND - products that have all selected terms', 'testo' )
						),
						'author' => array(
							'default' => '',
							'name' => __( 'Authors', 'testo' ),
							'desc' => __( 'Enter here comma-separated list of author\'s IDs. Example: 1,7,18', 'testo' )
						),
						'offset' => array(
							'type' => 'number',
							'min' => 0,
							'max' => 10000,
							'step' => 1, 'default' => 0,
							'name' => __( 'Offset', 'testo' ),
							'desc' => __( 'Specify offset to start products loop not from first products', 'testo' )
						),
						'order' => array(
							'type' => 'select',
							'values' => array(
								'desc' => __( 'Descending', 'testo' ),
								'asc' => __( 'Ascending', 'testo' )
							),
							'default' => 'DESC',
							'name' => __( 'Order', 'testo' ),
							'desc' => __( 'Products order', 'testo' )
						),
						'orderby' => array(
							'type' => 'select',
							'values' => array(
								'none' => __( 'None', 'testo' ),
								'id' => __( 'Products ID', 'testo' ),
								'author' => __( 'Products author', 'testo' ),
								'title' => __( 'Products title', 'testo' ),
								'name' => __( 'Products slug', 'testo' ),
								'date' => __( 'Date', 'testo' ), 
								'modified' => __( 'Last modified date', 'testo' ),
								'parent' => __( 'Products parent', 'testo' ),
								'rand' => __( 'Random', 'testo' ), 
								'comment_count' => __( 'Comments number', 'testo' ),
								'menu_order' => __( 'Menu order', 'testo' ), 
								'meta_value' => __( 'Meta key values', 'testo' ),
							),
							'default' => 'date',
							'name' => __( 'Order by', 'testo' ),
							'desc' => __( 'Order products by', 'testo' )
						),
						'post_parent' => array(
							'default' => '',
							'name' => __( 'Product parent', 'testo' ),
							'desc' => __( 'Show childrens of entered product (enter product ID)', 'testo' )
						),
						'post_status' => array(
							'type' => 'select',
							'values' => array(
								'publish' => __( 'Published', 'testo' ),
								'pending' => __( 'Pending', 'testo' ),
								'draft' => __( 'Draft', 'testo' ),
								'auto-draft' => __( 'Auto-draft', 'testo' ),
								'future' => __( 'Future course', 'testo' ),
								'private' => __( 'Private course', 'testo' ),
								'inherit' => __( 'Inherit', 'testo' ),
								'trash' => __( 'Trashed', 'testo' ),
								'any' => __( 'Any', 'testo' ),
							),
							'default' => 'publish',
							'name' => __( 'Products status', 'testo' ),
							'desc' => __( 'Show only products with selected status', 'testo' )
						),
						'ignore_sticky_posts' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Ignore sticky', 'testo' ),
							'desc' => __( 'Select Yes to ignore products that is sticked', 'testo' )
						)
					),
					'desc' => __( 'Custom products query with customizable template', 'testo' ),
					'icon' => 'th-list'
				),
				// dummy_text
				'dummy_text' => array(
					'name' => __( 'Dummy text', 'testo' ),
					'type' => 'single',
					'group' => 'content',
					'atts' => array(
						'what' => array(
							'type' => 'select',
							'values' => array(
								'paras' => __( 'Paragraphs', 'testo' ),
								'words' => __( 'Words', 'testo' ),
								'bytes' => __( 'Bytes', 'testo' ),
							),
							'default' => 'paras',
							'name' => __( 'What', 'testo' ),
							'desc' => __( 'What to generate', 'testo' )
						),
						'amount' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 100,
							'step' => 1,
							'default' => 1,
							'name' => __( 'Amount', 'testo' ),
							'desc' => __( 'How many items (paragraphs or words) to generate. Minimum words amount is 5', 'testo' )
						),
						'cache' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Cache', 'testo' ),
							'desc' => __( 'Generated text will be cached. Be careful with this option. If you disable it and insert many dummy_text shortcodes the page load time will be highly increased', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'desc' => __( 'Text placeholder', 'testo' ),
					'icon' => 'text-height'
				),
				// dummy_image
				'dummy_image' => array(
					'name' => __( 'Dummy image', 'testo' ),
					'type' => 'single',
					'group' => 'content',
					'atts' => array(
						'width' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 1600,
							'step' => 10,
							'default' => 500,
							'name' => __( 'Width', 'testo' ),
							'desc' => __( 'Image width', 'testo' )
						),
						'height' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 1600,
							'step' => 10,
							'default' => 300,
							'name' => __( 'Height', 'testo' ),
							'desc' => __( 'Image height', 'testo' )
						),
						'theme' => array(
							'type' => 'select',
							'values' => array(
								'any'       => __( 'Any', 'testo' ),
								'abstract'  => __( 'Abstract', 'testo' ),
								'animals'   => __( 'Animals', 'testo' ),
								'business'  => __( 'Business', 'testo' ),
								'cats'      => __( 'Cats', 'testo' ),
								'city'      => __( 'City', 'testo' ),
								'food'      => __( 'Food', 'testo' ),
								'nightlife' => __( 'Night life', 'testo' ),
								'fashion'   => __( 'Fashion', 'testo' ),
								'people'    => __( 'People', 'testo' ),
								'nature'    => __( 'Nature', 'testo' ),
								'sports'    => __( 'Sports', 'testo' ),
								'technics'  => __( 'Technics', 'testo' ),
								'transport' => __( 'Transport', 'testo' )
							),
							'default' => 'any',
							'name' => __( 'Theme', 'testo' ),
							'desc' => __( 'Select the theme for this image', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'desc' => __( 'Image placeholder with random image', 'testo' ),
					'icon' => 'picture-o'
				),
				// animate
				'animate' => array(
					'name' => __( 'Animation', 'testo' ),
					'type' => 'wrap',
					'group' => 'other',
					'atts' => array(
						'type' => array(
							'type' => 'select',
							'values' => array_combine( self::animations(), self::animations() ),
							'default' => 'bounceIn',
							'name' => __( 'Animation', 'testo' ),
							'desc' => __( 'Select animation type', 'testo' )
						),
						'duration' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 20,
							'step' => 0.5,
							'default' => 1,
							'name' => __( 'Duration', 'testo' ),
							'desc' => __( 'Animation duration (seconds)', 'testo' )
						),
						'delay' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 20,
							'step' => 0.5,
							'default' => 0,
							'name' => __( 'Delay', 'testo' ),
							'desc' => __( 'Animation delay (seconds)', 'testo' )
						),
						'inline' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Inline', 'testo' ),
							'desc' => __( 'This parameter determines what HTML tag will be used for animation wrapper. Turn this option to YES and animated element will be wrapped in SPAN instead of DIV. Useful for inline animations, like buttons', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Animated content', 'testo' ),
					'desc' => __( 'Wrapper for animation. Any nested element will be animated', 'testo' ),
					'example' => 'animations',
					'icon' => 'bolt'
				),
				// meta
				'meta' => array(
					'name' => __( 'Meta', 'testo' ),
					'type' => 'single',
					'group' => 'data',
					'atts' => array(
						'key' => array(
							'default' => '',
							'name' => __( 'Key', 'testo' ),
							'desc' => __( 'Meta key name', 'testo' )
						),
						'default' => array(
							'default' => '',
							'name' => __( 'Default', 'testo' ),
							'desc' => __( 'This text will be shown if data is not found', 'testo' )
						),
						'before' => array(
							'default' => '',
							'name' => __( 'Before', 'testo' ),
							'desc' => __( 'This content will be shown before the value', 'testo' )
						),
						'after' => array(
							'default' => '',
							'name' => __( 'After', 'testo' ),
							'desc' => __( 'This content will be shown after the value', 'testo' )
						),
						'post_id' => array(
							'default' => '',
							'name' => __( 'Post ID', 'testo' ),
							'desc' => __( 'You can specify custom post ID. Leave this field empty to use an ID of the current post. Current post ID may not work in Live Preview mode', 'testo' )
						),
						'filter' => array(
							'default' => '',
							'name' => __( 'Filter', 'testo' ),
							'desc' => __( 'You can apply custom filter to the retrieved value. Enter here function name. Your function must accept one argument and return modified value. Example function: ', 'testo' ) . "<br /><pre><code style='display:block;padding:5px'>function my_custom_filter( \$value ) {\n\treturn 'Value is: ' . \$value;\n}</code></pre>"
						)
					),
					'desc' => __( 'Post meta', 'testo' ),
					'icon' => 'info-circle'
				),
				// user
				'user' => array(
					'name' => __( 'User', 'testo' ),
					'type' => 'single',
					'group' => 'data',
					'atts' => array(
						'field' => array(
							'type' => 'select',
							'values' => array(
								'display_name'        => __( 'Display name', 'testo' ),
								'ID'                  => __( 'ID', 'testo' ),
								'user_login'          => __( 'Login', 'testo' ),
								'user_nicename'       => __( 'Nice name', 'testo' ),
								'user_email'          => __( 'Email', 'testo' ),
								'user_url'            => __( 'URL', 'testo' ),
								'user_registered'     => __( 'Registered', 'testo' ),
								'user_activation_key' => __( 'Activation key', 'testo' ),
								'user_status'         => __( 'Status', 'testo' )
							),
							'default' => 'display_name',
							'name' => __( 'Field', 'testo' ),
							'desc' => __( 'User data field name', 'testo' )
						),
						'default' => array(
							'default' => '',
							'name' => __( 'Default', 'testo' ),
							'desc' => __( 'This text will be shown if data is not found', 'testo' )
						),
						'before' => array(
							'default' => '',
							'name' => __( 'Before', 'testo' ),
							'desc' => __( 'This content will be shown before the value', 'testo' )
						),
						'after' => array(
							'default' => '',
							'name' => __( 'After', 'testo' ),
							'desc' => __( 'This content will be shown after the value', 'testo' )
						),
						'user_id' => array(
							'default' => '',
							'name' => __( 'User ID', 'testo' ),
							'desc' => __( 'You can specify custom user ID. Leave this field empty to use an ID of the current user', 'testo' )
						),
						'filter' => array(
							'default' => '',
							'name' => __( 'Filter', 'testo' ),
							'desc' => __( 'You can apply custom filter to the retrieved value. Enter here function name. Your function must accept one argument and return modified value. Example function: ', 'testo' ) . "<br /><pre><code style='display:block;padding:5px'>function my_custom_filter( \$value ) {\n\treturn 'Value is: ' . \$value;\n}</code></pre>"
						)
					),
					'desc' => __( 'User data', 'testo' ),
					'icon' => 'info-circle'
				),
				// post
				'post' => array(
					'name' => __( 'Post', 'testo' ),
					'type' => 'single',
					'group' => 'data',
					'atts' => array(
						'field' => array(
							'type' => 'select',
							'values' => array(
								'ID'                    => __( 'Post ID', 'testo' ),
								'post_author'           => __( 'Post author', 'testo' ),
								'post_date'             => __( 'Post date', 'testo' ),
								'post_date_gmt'         => __( 'Post date', 'testo' ) . ' GMT',
								'post_content'          => __( 'Post content', 'testo' ),
								'post_title'            => __( 'Post title', 'testo' ),
								'post_excerpt'          => __( 'Post excerpt', 'testo' ),
								'post_status'           => __( 'Post status', 'testo' ),
								'comment_status'        => __( 'Comment status', 'testo' ),
								'ping_status'           => __( 'Ping status', 'testo' ),
								'post_name'             => __( 'Post name', 'testo' ),
								'post_modified'         => __( 'Post modified', 'testo' ),
								'post_modified_gmt'     => __( 'Post modified', 'testo' ) . ' GMT',
								'post_content_filtered' => __( 'Filtered post content', 'testo' ),
								'post_parent'           => __( 'Post parent', 'testo' ),
								'guid'                  => __( 'GUID', 'testo' ),
								'menu_order'            => __( 'Menu order', 'testo' ),
								'post_type'             => __( 'Post type', 'testo' ),
								'post_mime_type'        => __( 'Post mime type', 'testo' ),
								'comment_count'         => __( 'Comment count', 'testo' )
							),
							'default' => 'post_title',
							'name' => __( 'Field', 'testo' ),
							'desc' => __( 'Post data field name', 'testo' )
						),
						'default' => array(
							'default' => '',
							'name' => __( 'Default', 'testo' ),
							'desc' => __( 'This text will be shown if data is not found', 'testo' )
						),
						'before' => array(
							'default' => '',
							'name' => __( 'Before', 'testo' ),
							'desc' => __( 'This content will be shown before the value', 'testo' )
						),
						'after' => array(
							'default' => '',
							'name' => __( 'After', 'testo' ),
							'desc' => __( 'This content will be shown after the value', 'testo' )
						),
						'post_id' => array(
							'default' => '',
							'name' => __( 'Post ID', 'testo' ),
							'desc' => __( 'You can specify custom post ID. Leave this field empty to use an ID of the current post. Current post ID may not work in Live Preview mode', 'testo' )
						),
						'filter' => array(
							'default' => '',
							'name' => __( 'Filter', 'testo' ),
							'desc' => __( 'You can apply custom filter to the retrieved value. Enter here function name. Your function must accept one argument and return modified value. Example function: ', 'testo' ) . "<br /><pre><code style='display:block;padding:5px'>function my_custom_filter( \$value ) {\n\treturn 'Value is: ' . \$value;\n}</code></pre>"
						)
					),
					'desc' => __( 'Post data', 'testo' ),
					'icon' => 'info-circle'
				),
				// post_terms
				// 'post_terms' => array(
				// 	'name' => __( 'Post terms', 'testo' ),
				// 	'type' => 'single',
				// 	'group' => 'data',
				// 	'atts' => array(
				// 		'post_id' => array(
				// 			'default' => '',
				// 			'name' => __( 'Post ID', 'testo' ),
				// 			'desc' => __( 'You can specify custom post ID. Leave this field empty to use an ID of the current post. Current post ID may not work in Live Preview mode', 'testo' )
				// 		),
				// 		'links' => array(
				// 			'type' => 'bool',
				// 			'default' => 'yes',
				// 			'name' => __( 'Show links', 'testo' ),
				// 			'desc' => __( 'Show terms names as hyperlinks', 'testo' )
				// 		),
				// 		'format' => array(
				// 			'type' => 'select',
				// 			'values' => array(
				// 				'text' => __( 'Terms separated by commas', 'testo' ),
				// 				'br' => __( 'Terms separated by new lines', 'testo' ),
				// 				'ul' => __( 'Unordered list', 'testo' ),
				// 				'ol' => __( 'Ordered list', 'testo' ),
				// 			),
				// 			'default' => 'text',
				// 			'name' => __( 'Format', 'testo' ),
				// 			'desc' => __( 'Choose how to output the terms', 'testo' )
				// 		),
				// 	),
				// 	'desc' => __( 'Terms list', 'testo' ),
				// 	'icon' => 'info-circle'
				// ),
				// template
				'template' => array(
					'name' => __( 'Template', 'testo' ),
					'type' => 'single',
					'group' => 'other',
					'atts' => array(
						'name' => array(
							'default' => '',
							'name' => __( 'Template name', 'testo' ),
							'desc' => sprintf( __( 'Use template file name (with optional .php extension). If you need to use templates from theme sub-folder, use relative path. Example values: %s, %s, %s', 'testo' ), '<b%value>page</b>', '<b%value>page.php</b>', '<b%value>includes/page.php</b>' )
						)
					),
					'desc' => __( 'Theme template', 'testo' ),
					'icon' => 'puzzle-piece'
				),
				// qrcode
				'qrcode' => array(
					'name' => __( 'QR code', 'testo' ),
					'type' => 'single',
					'group' => 'content',
					'atts' => array(
						'data' => array(
							'default' => '',
							'name' => __( 'Data', 'testo' ),
							'desc' => __( 'The text to store within the QR code. You can use here any text or even URL', 'testo' )
						),
						'title' => array(
							'default' => '',
							'name' => __( 'Title', 'testo' ),
							'desc' => __( 'Enter here short description. This text will be used in alt attribute of QR code', 'testo' )
						),
						'size' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 1000,
							'step' => 10,
							'default' => 200,
							'name' => __( 'Size', 'testo' ),
							'desc' => __( 'Image width and height (in pixels)', 'testo' )
						),
						'margin' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 50,
							'step' => 5,
							'default' => 0,
							'name' => __( 'Margin', 'testo' ),
							'desc' => __( 'Thickness of a margin (in pixels)', 'testo' )
						),
						'align' => array(
							'type' => 'select',
							'values' => array(
								'none' => __( 'None', 'testo' ),
								'left' => __( 'Left', 'testo' ),
								'center' => __( 'Center', 'testo' ),
								'right' => __( 'Right', 'testo' ),
							),
							'default' => 'none',
							'name' => __( 'Align', 'testo' ),
							'desc' => __( 'Choose image alignment', 'testo' )
						),
						'link' => array(
							'default' => '',
							'name' => __( 'Link', 'testo' ),
							'desc' => __( 'You can make this QR code clickable. Enter here the URL', 'testo' )
						),
						'target' => array(
							'type' => 'select',
							'values' => array(
								'self' => __( 'Open link in same window/tab', 'testo' ),
								'blank' => __( 'Open link in new window/tab', 'testo' ),
							),
							'default' => 'blank',
							'name' => __( 'Link target', 'testo' ),
							'desc' => __( 'Select link target', 'testo' )
						),
						'color' => array(
							'type' => 'color',
							'default' => '#000000',
							'name' => __( 'Primary color', 'testo' ),
							'desc' => __( 'Pick a primary color', 'testo' )
						),
						'background' => array(
							'type' => 'color',
							'default' => '#ffffff',
							'name' => __( 'Background color', 'testo' ),
							'desc' => __( 'Pick a background color', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'desc' => __( 'Advanced QR code generator', 'testo' ),
					'icon' => 'qrcode'
				),
				
				// products_carousel
				'products_carousel' => array(
					'name' => __( 'Product Carousel', 'testo' ),
					'type' => 'single',
					'group' => 'testo',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'style_1' => __( 'Style 1', 'testo' ),
								'style_2' => __( 'Style 2', 'testo' ),
							),
							'default' => 'style_1',
							'name' => __( 'Style', 'testo' ),
							'desc' => __( 'Select style of product carousel', 'testo' )
						),
						'posts_per_page' => array(
							'type' => 'number',
							'min' => -1,
							'max' => 10000,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Product per page', 'testo' ),
							'desc' => __( 'Specify number of Product that you want to show. Enter -1 to get all Product', 'testo' )
						),
						'taxonomy' => array(
							'type' => 'select',
							'values' => array(
								'product_cat' => __( 'Product Category', 'testo' ),
								'product_tag' => __( 'Product Tag', 'testo' ),
							),
							'default' => 'product_cat',
							'name' => __( 'Taxonomy', 'testo' ),
							'desc' => __( 'Select taxonomy to show products from', 'testo' )
						),
						'tax_term' => array(
							'type' => 'select',
							'multiple' => true,
							'values' => Ts_Tools::get_terms( 'category' ),
							'default' => '',
							'name' => __( 'Terms', 'testo' ),
							'desc' => __( 'Select terms to show products from', 'testo' )
						),
						'tax_operator' => array(
							'type' => 'select',
							'values' => array( 'IN', 'NOT IN', 'AND' ),
							'default' => 'IN', 'name' => __( 'Taxonomy term operator', 'testo' ),
							'desc' => __( 'IN - products that have any of selected categories terms<br/>NOT IN - products that is does not have any of selected terms<br/>AND - products that have all selected terms', 'testo' )
						),
						'order' => array(
							'type' => 'select',
							'values' => array(
								'desc' => __( 'Descending', 'testo' ),
								'asc' => __( 'Ascending', 'testo' )
							),
							'default' => 'DESC',
							'name' => __( 'Order', 'testo' ),
							'desc' => __( 'Product order', 'testo' )
						),
						'orderby' => array(
							'type' => 'select',
							'values' => array(
								'none' => __( 'None', 'testo' ),
								'id' => __( 'Product ID', 'testo' ),
								'title' => __( 'Product title', 'testo' ),
								'name' => __( 'Product slug', 'testo' ),
								'date' => __( 'Date', 'testo' ),
								'modified' => __( 'Last modified date', 'testo' ),
							),
							'default' => 'date',
							'name' => __( 'Order by', 'testo' ),
							'desc' => __( 'Order product by', 'testo' )
						),
						'best_seller' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Best Seller', 'testo' ),
							'desc' => __( 'Is product best seller or not', 'testo' )
						),					
					),
					'desc' => __( 'Custom product carousel', 'testo' ),
					'icon' => 'th-list'
				),
				
				// title_subtitle
				'title_subtitle' => array(
					'name' => __( 'Title & Sub-title', 'testo' ),
					'type' => 'single',
					'group' => 'testo',
					'atts' => array(
						'title' => array(
							'default' => '',
							'name' => __( 'Title', 'testo' ),
							'desc' => __( 'Title', 'testo' )
						),
						'title_font_size' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 100,
							'step' => 1,
							'default' => 55,
							'name' => __( 'Title Font Size', 'testo' ),
							'desc' => __( 'Font size of Title(in pixels)', 'testo' )
						),
						'subtitle' => array(
							'type'		=> 'textarea',
							'default' => '',
							'name' => __( 'Sub-Title', 'testo' ),
							'desc' => __( 'Sub-Title', 'testo' )
						),
						'margin_bottom' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 100,
							'step' => 1,
							'default' => 45,
							'name' => __( 'Margin Bottom', 'testo' ),
							'desc' => __( 'Bottom Margin of title', 'testo' )
						),
					),
					
					'class'=> '',
					'desc' => __( 'Single title and sub-title', 'testo' ),
					'icon' => 'link'
				),
				
				//Team
			'team' =>
				array(
					'name' => __( 'Team', 'testo' ),
					'type' => 'wrap',
					'group' => 'testo',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'default' => __( 'Default', 'testo' ),
								'style_2' => __( 'Style 2', 'testo' )
							),
							'default' => 'default',
							'name' => __( 'Style', 'testo' ),
							'desc' => __( 'Choose style for team', 'testo' ) . '%ts_skins_link%'
						),
						'name' => array(
							'type' => 'text',
							'default' => 'John DOE',
							'name' => __( 'Name', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'title' => array(
							'type' => 'text',
							'default' => 'Web Designer',
							'name' => __( 'Title', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'image' => array(
							'type' => 'upload',
							'default' => '',
							'name' => __( 'Upload Photo', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'facebook_link' => array(
							'type' => 'text',
							'default' => '',
							'name' => __( 'Facebook Link', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'twitter_link' => array(
							'type' => 'text',
							'default' => '',
							'name' => __( 'Twitter Link', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'linked_in_link' => array(
							'type' => 'text',
							'default' => '',
							'name' => __( 'LinkedIn Link', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'testo' ),
							'desc' => __( 'Extra CSS class', 'testo' )
						)
					),
					'content' => __( 'Lorem ipsum dol sit  amet et test description..', 'testo' ),
					'desc' => __( '', 'testo' ),
					'icon' => 'male'
				),
				
				// title_span_box
				'title_span_box' => array(
					'name' => __( 'Title & Span', 'testo' ),
					'type' => 'wrap',
					'group' => 'testo',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'style_1' => __( 'Style 1', 'testo' ),
								'style_2' => __( 'Style 2', 'testo' ),
							),
							'default' => 'style_1',
							'name' => __( 'Style', 'testo' ),
							'desc' => __( 'Select your title style', 'testo' )
						),
						'title' => array(
							'default' => '',
							'name' => __( 'Title', 'testo' ),
							'desc' => __( 'Title', 'testo' )
						),
						'title_size' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 70,
							'step' => 1,
							'default' => 40,
							'name' => __( 'Title Font Size', 'testo' ),
							'desc' => __( 'Font size of Title(in pixels)', 'testo' )
						),
						'title_color' => array(
							'type' => 'color',
							'default' => '#ffffff',
							'name' => __( 'Title Color', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'span_content' => array(
							'default' => '',
							'name' => __( 'Span Content', 'testo' ),
							'desc' => __( 'Span content', 'testo' )
						),
						'span_color' => array(
							'type' => 'color',
							'default' => '#121212',
							'name' => __( 'Span Color', 'testo' ),
							'desc' => __( '', 'testo' )
						),
						'span_size' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 70,
							'step' => 1,
							'default' => 40,
							'name' => __( 'Span Content Size', 'testo' ),
							'desc' => __( 'Font size of span', 'testo' )
						),
						'description' => array(
							'default' => '',
							'name' => __( 'Description', 'testo' ),
							'desc' => __( 'Description', 'testo' )
						),
						'des_color' => array(
							'type' => 'color',
							'default' => '#ffffff',
							'name' => __( 'Description Color', 'testo' ),
							'desc' => __( '', 'testo' )
						),						
						'box_align' => array(
							'type' => 'select',
							'values' => array(
								'box-center' => __( 'Center', 'testo' ),
								'box-left' => __( 'Left', 'testo' ),
								'box-right' => __( 'Right', 'testo' ),
							),
							'default' => 'box-right',
							'name' => __( 'Box Align', 'testo' ),
							'desc' => __( 'Choose box align', 'testo' )
						),
					),
					
					'class'=> '',
					'desc' => __( 'Button shortcode goes here', 'testo' ),
					'icon' => 'link'
				),
				
				// agencies
				'agencies' => array(
					'name' => __( 'Agencies', 'testo' ),
					'type' => 'single',
					'group' => 'testo',
					'atts' => array(
						'per_page' => array(
							'type' => 'number',
							'min' => 1,
							'max' => 100000000,
							'step' => 1,
							'default' => 12,
							'name' => __( 'Number of Agency', 'testo' ),
							'desc' => __( 'Specify number of agency that you want to show. Enter -1 to get all agency', 'testo' )
						),
						'column' => array(
							'type' => 'number',
							'min' => 1,
							'max' => 4,
							'step' => 1,
							'default' => 3,
							'name' => __( 'Column', 'testo' ),
							'desc' => __( 'Number of column', 'testo' )
						),
						'nav' => array(
							'type' => 'bool',
							'default' => 'yes',
							'name' => __( 'Pagination', 'testo' ),
							'desc' => __( 'Show Pagination', 'testo' )
						),						
					),
					'desc' => __( 'Agencies', 'testo' ),
					'icon' => 'users'
				),
				
				// scheduler
				'scheduler' => array(
					'name' => __( 'Scheduler', 'testo' ),
					'type' => 'wrap',
					'group' => 'other',
					'atts' => array(
						'time' => array(
							'default' => '',
							'name' => __( 'Time', 'testo' ),
							'desc' => sprintf( __( 'In this field you can specify one or more time ranges. Every day at this time the content of shortcode will be visible. %s %s %s - show content from 9:00 to 18:00 %s - show content from 9:00 to 13:00 and from 14:00 to 18:00 %s - example with minutes (content will be visible each day, 45 minutes) %s - example with seconds', 'testo' ), '<br><br>', __( 'Examples (click to set)', 'testo' ), '<br><b%value>9-18</b>', '<br><b%value>9-13, 14-18</b>', '<br><b%value>9:30-10:15</b>', '<br><b%value>9:00:00-17:59:59</b>' )
						),
						'days_week' => array(
							'default' => '',
							'name' => __( 'Days of the week', 'testo' ),
							'desc' => sprintf( __( 'In this field you can specify one or more days of the week. Every week at these days the content of shortcode will be visible. %s 0 - Sunday %s 1 - Monday %s 2 - Tuesday %s 3 - Wednesday %s 4 - Thursday %s 5 - Friday %s 6 - Saturday %s %s %s - show content from Monday to Friday %s - show content only at Sunday %s - show content at Sunday and from Wednesday to Friday', 'testo' ), '<br><br>', '<br>', '<br>', '<br>', '<br>', '<br>', '<br>', '<br><br>', __( 'Examples (click to set)', 'testo' ), '<br><b%value>1-5</b>', '<br><b%value>0</b>', '<br><b%value>0, 3-5</b>' )
						),
						'days_month' => array(
							'default' => '',
							'name' => __( 'Days of the month', 'testo' ),
							'desc' => sprintf( __( 'In this field you can specify one or more days of the month. Every month at these days the content of shortcode will be visible. %s %s %s - show content only at first day of month %s - show content from 1th to 5th %s - show content from 10th to 15th and from 20th to 25th', 'testo' ), '<br><br>', __( 'Examples (click to set)', 'testo' ), '<br><b%value>1</b>', '<br><b%value>1-5</b>', '<br><b%value>10-15, 20-25</b>' )
						),
						'months' => array(
							'default' => '',
							'name' => __( 'Months', 'testo' ),
							'desc' => sprintf( __( 'In this field you can specify the month or months in which the content will be visible. %s %s %s - show content only in January %s - show content from February to June %s - show content in January, March and from May to July', 'testo' ), '<br><br>', __( 'Examples (click to set)', 'testo' ), '<br><b%value>1</b>', '<br><b%value>2-6</b>', '<br><b%value>1, 3, 5-7</b>' )
						),
						'years' => array(
							'default' => '',
							'name' => __( 'Years', 'testo' ),
							'desc' => sprintf( __( 'In this field you can specify the year or years in which the content will be visible. %s %s %s - show content only in 2014 %s - show content from 2014 to 2016 %s - show content in 2014, 2018 and from 2020 to 2022', 'testo' ), '<br><br>', __( 'Examples (click to set)', 'testo' ), '<br><b%value>2014</b>', '<br><b%value>2014-2016</b>', '<br><b%value>2014, 2018, 2020-2022</b>' )
						),
						'alt' => array(
							'default' => '',
							'name' => __( 'Alternative text', 'testo' ),
							'desc' => __( 'In this field you can type the text which will be shown if content is not visible at the current moment', 'testo' )
						)
					),
					'content' => __( 'Scheduled content', 'testo' ),
					'desc' => __( 'Allows to show the content only at the specified time period', 'testo' ),
					'note' => __( 'This shortcode allows you to show content only at the specified time.', 'testo' ) . '<br><br>' . __( 'Please pay special attention to the descriptions, which are located below each text field. It will save you a lot of time', 'testo' ) . '<br><br>' . __( 'By default, the content of this shortcode will be visible all the time. By using fields below, you can add some limitations. For example, if you type 1-5 in the Days of the week field, content will be only shown from Monday to Friday. Using the same principles, you can limit content visibility from years to seconds.', 'testo' ),
					'icon' => 'clock-o'
				),
			) );
		// Return result
		return ( is_string( $shortcode ) ) ? $shortcodes[sanitize_text_field( $shortcode )] : $shortcodes;
	}
}

class Testo_Shortcodes_Data extends Ts_Data {
	function __construct() {
		parent::__construct();
	}
}

<?php
/**
 * Custom CSS and JS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * CustomCSSandJS_Debug
 */
class CustomCSSandJS_Debug {

	/**
	 * Constructor
	 */
	public function __construct() {
	}

}

return new CustomCSSandJS_Debug();
